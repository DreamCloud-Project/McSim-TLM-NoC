#! /usr/bin/env python2

import argparse
import os
import subprocess

def main():
    ''' Compile the abstract simulator '''

    # Configure parameters parser
    parser = argparse.ArgumentParser(description='Abstract Simulator Compiler script')
    subparsers = parser.add_subparsers(title='valid subcommands', dest='command')
    parser_cp = subparsers.add_parser('build')
    parser_cp.add_argument("-c", '--clean', action='store_true', help='clean previously compiled files before compiling')
    parser_cp.add_argument('-v',  '--verbose', action='store_true', help='enable verbose output')
    parser_cl = subparsers.add_parser('clean')
    parser_cl.add_argument('-v',  '--verbose', action='store_true', help='enable verbose output')

    # Get parameters
    args = parser.parse_args()
    my_env = os.environ.copy()
    sc_home = my_env.get('SYSTEMC_HOME', '')
    if not sc_home:
        sys.stderr.write('You must define the SYSTEMC_HOME variable to use this script')
        sys.exit(-1)

    if args.command == 'clean' or args.clean:
        print ('Cleaning the abstract simulator previous build ...')
        work_dir = './src/Platform_Src'
        cmd = ['make', 'clean']
        if not args.verbose:
            clean = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work_dir)
        else:
            print (cmd)
            clean = subprocess.Popen(cmd, cwd=work_dir)
        if clean.wait() != 0:
            print ('Cleaning FAILED')
            exit(-1)
        work_dir = './src/Energy_Estimator'
        if not args.verbose:
            clean = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work_dir)
        else:
            print (cmd)
            clean = subprocess.Popen(cmd, cwd=work_dir)
        if clean.wait() != 0:
            print ('Cleaning FAILED')
            exit(-1)
        print ('Cleaning done')
    if args.command == 'build':
        work_dir = './src/Platform_Src'
        cmd = ['make', 'build']
        if not args.verbose:
             build = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work_dir)
        else:
            print (cmd)
            build = subprocess.Popen(cmd, cwd=work_dir)
        if build.wait() != 0:
            print ('Bulding FAILED')
            exit(-1)
        work_dir = './src/Energy_Estimator'
        if not args.verbose:
             build = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work_dir)
        else:
            print (cmd)
            build = subprocess.Popen(cmd, cwd=work_dir)
        if build.wait() != 0:
            print ('Bulding FAILED')
            exit(-1)
        print ('Building done')

# This script runs the main
if __name__ == "__main__":
    main()
