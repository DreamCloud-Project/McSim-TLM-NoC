#!/usr/bin/perl -w
################################################################################
#                                                                              #
#                            DREAMCLOUD PROJECT                                #
#                                                                              #
################################################################################

use strict;
use warnings;

die("usage:\n\tFindDependencies.pl topdir prefix\n\n") unless @ARGV == 2;

my $topdir = shift @ARGV;
my $prefix = shift @ARGV;
$topdir =~ s/\/\//\//g;
my @targets = ();

my %depends;

sub add_dependencies
{
  my $depends = shift;

  my @dependencies = split(/\s+/,$depends);

  foreach my $dependency (@dependencies)
  {
    next unless $dependency;
    $dependency =~ s/\/\//\//g;
    foreach my $target (@targets)
    {
      push @{$depends{$target}}, $dependency;
    }
  }
}

while(my $line=<>)
{
  if ($line =~ /:/)
  {
    (my $target, my $depend,my $continue) = ($line =~ /(.*):([^\\]*)(\\?)/);
    warn "Target already found" if @targets;
    @targets = split(/\s+/,$target);
    add_dependencies($depend);
    @targets = () unless $continue;
  } 
  else
  {
    (my $depend,my $continue) = ($line =~ /([^\\]*)(\\?)/);
    warn "Target not found" unless @targets or ($line =~ /^\s*$/);
    add_dependencies($depend);
    @targets = () unless $continue;
  }
}

foreach my $target (keys %depends)
{
  print "$prefix$target: ";
  my @depends = grep {/^($topdir|[^\/])/} (@{$depends{$target}});
  print join(" ",@depends);
  print "\n";
}

################################################################################
#                                                                              #
#  END OF FILE.                                                                #
#                                                                              #
################################################################################
