////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__UTILITIES_CLIB__MESSENGER_HXX
#define DREAMCLOUD__UTILITIES_CLIB__MESSENGER_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <string>
#include <iostream>
#include <boost/format.hpp>
#include <exception>

namespace dreamcloud { namespace utilities_clib { namespace Messenger {

////////////////////
//      USING     //
////////////////////
using std::string;
using std::ostream;
using std::ios;
using std::ios_base;
using std::exception;

extern int dbg_level_;
      
enum logTypeEnum
{
  MSG_INFO,
  MSG_DEBUG,
  MSG_WARNING,
  MSG_ERROR,
  MSG_FAILURE,
  IGNORE,
};


class Exception: public exception
{
public:
  Exception(string description):description_(description) { }
  virtual const char * what () const throw() {return description_.c_str();}
  ~Exception() throw() { }
private:
  string description_;
};

class Failure: public Exception
{
public:
  Failure(const string &description): Exception(description) { };
private:
};

void messenger_(int level, logTypeEnum type, const string &str);
bool is_allowed_(int level);

#define debug_(debug_level, format_string, vars) \
  { if (is_allowed_(debug_level)) { \
    try { \
      messenger_(debug_level, MSG_DEBUG, str(boost::format(format_string) % vars)); \
    } \
    catch(boost::io::format_error &e)\
   { \
     messenger_(debug_level, MSG_DEBUG, "Error in format_string: "+format_string); \
   } \
  }}

template<class C1>
inline void debug(const int debug_level, const string &s, const C1 &a1)
{
  debug_(debug_level,s,a1);
}

inline void debug(int debug_level, const string &format_string) 
  { debug(debug_level,(format_string+"%1%"),""); }

template<class C1, class C2>
inline void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2)
{
  debug_(debug_level,s,a1%a2);
}

template<class C1, class C2, class C3>
inline void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2, const C3 &a3)
{
  debug_(debug_level,s,a1%a2%a3);
}

template<class C1, class C2, class C3,class C4>
inline void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4)
{
  debug_(debug_level,s,a1%a2%a3%a4);
}

template<class C1, class C2, class C3,class C4,class C5>
inline void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5)
{
  debug_(debug_level,s,a1%a2%a3%a4%a5);
}

template<class C1, class C2, class C3,class C4,class C5,class C6>
inline void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6)
{
  debug_(debug_level,s,a1%a2%a3%a4%a5%a6);
}

template<class C1, class C2, class C3,class C4,class C5,class C6, class C7>
void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7)
{
  debug_(debug_level,s,a1%a2%a3%a4%a5%a6%a7);
}

template<class C1, class C2, class C3,class C4,class C5,class C6, class C7, class C8>
inline void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8)
{
  debug_(debug_level,s,a1%a2%a3%a4%a5%a6%a7%a8);
}

template<class C1, class C2, class C3,class C4,class C5,class C6, class C7, class C8, class C9>
inline void debug(const int debug_level, const string &s, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8, const C9 &a9)
{
  debug_(debug_level,s,a1%a2%a3%a4%a5%a6%a7%a8%a9);
}

#define logger_(type, format_string, vars) \
  { \
    try { \
      messenger_(0, type, str(boost::format(format_string) % vars)); \
    } \
    catch(boost::io::format_error &e) \
   { \
     messenger_(0, type, "Error in format_string: "+format_string); \
   } \
  }

#define messenger_throw_failure_(type, format_string, vars) \
  { \
    string s; \
    try { \
      messenger_(0, type, s=str(boost::format(format_string) % vars)); \
    } \
    catch(boost::io::format_error &e) \
   { \
     messenger_(0, type, s=("Error in format_string: "+format_string)); \
   } \
  }

 
inline void failure(const string &format_string) 
{
  messenger_(0, MSG_FAILURE, format_string);
}

template<class C1>
inline void failure(const string &format_string, const C1 &a1) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1);
}

template<class C1, class C2>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2);
}

template<class C1, class C2, class C3>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2%a3);
}

template<class C1, class C2, class C3, class C4>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2%a3%a4);
}

template<class C1, class C2, class C3, class C4, class C5>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2%a3%a4%a5);
}

template<class C1, class C2, class C3, class C4, class C5, class C6>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2%a3%a4%a5%a6);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2%a3%a4%a5%a6%a7);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2%a3%a4%a5%a6%a7%a8);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8, class C9>
inline void failure(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8, const C9 &a9) 
{
  messenger_throw_failure_(MSG_FAILURE, format_string, a1%a2%a3%a4%a5%a6%a7%a8%a9);
}

#define info_internal_(format_string, vars) { logger_(MSG_INFO, format_string, vars); }

inline void info(const string &format_string) 
{ 
  messenger_(0, MSG_INFO, format_string);
}

template<class C1>
inline void info(const string &format_string, const C1 &a1)
{
  info_internal_(format_string, a1);
}

template<class C1, class C2>
inline void info(const string &format_string, const C1 &a1, const C2 &a2)
{
  info_internal_(format_string, a1%a2);
}

template<class C1, class C2, class C3>
inline void info(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3)
{
  info_internal_(format_string, a1%a2%a3);
}

template<class C1, class C2, class C3, class C4>
inline void info(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4)
{ 
  info_internal_(format_string, a1%a2%a3%a4);
}

template<class C1, class C2, class C3, class C4, class C5>
inline void info(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5) 
{
  info_internal_(format_string, a1%a2%a3%a4%a5);
}

template<class C1, class C2, class C3, class C4, class C5, class C6>
inline void info(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6) 
{
  info_internal_(format_string, a1%a2%a3%a4%a5%a6);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7>
inline void info(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7) 
{
  info_internal_(format_string, a1%a2%a3%a4%a5%a6%a7);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8>
inline void info(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8) 
{
  info_internal_(format_string, a1%a2%a3%a4%a5%a6%a7%a8);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8, class C9>
void info(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8, const C9 &a9) 
{
  info_internal_(format_string, a1%a2%a3%a4%a5%a6%a7%a8%a9);
}

#define warning_internal_(format_string, vars) {logger_(MSG_WARNING, format_string, vars); }

inline void warning(const string &format_string) 
{
  messenger_(0, MSG_WARNING, format_string);
}

template<class C1>
inline void warning(const string &format_string, const C1 &a1) 
{
  warning_internal_(format_string, a1);
}

template<class C1, class C2>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2) 
{
  warning_internal_(format_string, a1%a2);
}

template<class C1, class C2, class C3>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3) 
{
  warning_internal_(format_string, a1%a2%a3);
}

template<class C1, class C2, class C3, class C4>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4) 
{
  warning_internal_(format_string, a1%a2%a3%a4);
}

template<class C1, class C2, class C3, class C4, class C5>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5) 
{
  warning_internal_(format_string, a1%a2%a3%a4%a5);
}

template<class C1, class C2, class C3, class C4, class C5, class C6>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6) 
{
  warning_internal_(format_string, a1%a2%a3%a4%a5%a6);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7) 
{
  warning_internal_(format_string, a1%a2%a3%a4%a5%a6%a7);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8) 
{
  warning_internal_(format_string, a1%a2%a3%a4%a5%a6%a7%a8);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8, class C9>
inline void warning(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8, const C9 &a9) 
{
  warning_internal_(format_string, a1%a2%a3%a4%a5%a6%a7%a8%a9);
}

#define error_(format_string, vars) {logger_(MSG_ERROR, format_string, vars); }

inline void error(const string &format_string) 
{
  messenger_(0, MSG_ERROR, format_string);
}

template<class C1>
inline void error(const string &format_string, const C1 &a1) 
{
  error_(format_string, a1);
}

template<class C1, class C2>
inline void error(const string &format_string, const C1 &a1, const C2 &a2) 
{
  error_(format_string, a1%a2);
}

template<class C1, class C2, class C3>
inline void error(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3) 
{
  error_(format_string, a1%a2%a3);
}

template<class C1, class C2, class C3, class C4>
inline void error(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4) 
{
  error_(format_string, a1%a2%a3%a4);
}

template<class C1, class C2, class C3, class C4, class C5>
inline void error(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5) 
{
  error_(format_string, a1%a2%a3%a4%a5);
}

template<class C1, class C2, class C3, class C4, class C5, class C6>
inline void error(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6) 
{
  error_(format_string, a1%a2%a3%a4%a5%a6);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7>
inline void error(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7) 
{
  error_(format_string, a1%a2%a3%a4%a5%a6%a7);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8>
inline void error(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8) 
{
  error_(format_string, a1%a2%a3%a4%a5%a6%a7%a8);
}

template<class C1, class C2, class C3, class C4, class C5, class C6, class C7, class C8, class C9>
inline void error(const string &format_string, const C1 &a1, const C2 &a2, const C3 &a3, const C4 &a4, const C5 &a5, const C6 &a6, const C7 &a7, const C8 &a8, const C9 &a9) 
{
  error_(format_string, a1%a2%a3%a4%a5%a6%a7%a8%a9);
}

inline void debug_level(int newvalue = dbg_level_)
{
  dbg_level_=newvalue;
}

}}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
