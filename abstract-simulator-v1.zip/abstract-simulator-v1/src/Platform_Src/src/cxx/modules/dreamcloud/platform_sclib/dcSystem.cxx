////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

////////////////////
//    INCLUDES    //
////////////////////
#include <fstream>
#include <utility>
#include <dreamcloud/platform_sclib/dcSystem.hxx>

namespace dreamcloud {
namespace platform_sclib {

/**
 * SystemC method used to get completed runnables from PEs and to enable
 * runnables dependent on the completed ones.
 */
void dcSystem::dependentRunnablesReleaser_method() {

	// Copy all completed runnables from PEs into dcSystem and erase them in PE_XY
	vector<string> ids;
	for (unsigned int x = 0; x < params.getRows(); x++) {
		for (unsigned int y = 0; y < params.getCols(); y++) {
			dcSharedPointer<processingElement> pe = pes[x][y];
			for (std::vector<string>::const_iterator i =
					pe->completedRunnableIDs.begin();
					i != pe->completedRunnableIDs.end(); ++i) {
				string id = *i;
				ids.push_back(id);
				nbRunnablesCompleted++;
			}
			pe->completedRunnableIDs.clear();
		}
	}

// When we don't handle periodics stop the simulation when all
// the runnables (periodic and non periodic) have been executed once
// or start a new iteration if needed
	if (simulationEnd == 0
			&& (params.dontHandlePeriodic() || hyperPeriod == 0)) {
		if (nbRunnablesCompleted / runnables.size() >= params.getIterations()) {
			stopSimu_event.notify();
			return;
		}
		if ((nbRunnablesCompleted % runnables.size()) == 0) {
			iteration_event.notify(0, SC_NS);
		}
	}

	// Loop over all the completed runnables
	for (vector<string>::size_type i = 0; i < ids.size(); ++i) {
		// Loop over all runnable that depend on the completed one
		dcRunnable* completedRunnable = applicaton->GetRunnable(taskGraph,
				ids.at(i));
		vector<dcRunnable*> enabledToExecute =
				completedRunnable->GetListOfEnables();
		for (std::vector<dcRunnable*>::iterator it = enabledToExecute.begin();
				it != enabledToExecute.end(); ++it) {
			// If all the previous runnables of the current dependent are completed, release it (the dependent one)
			if ((*it)->GetEnabledBy() == (*it)->GetListOfEnablers().size()) {
				releaseRunnable(*it);
			}
			// Else only indicate that one dependency has been satisfied
			else {
				(*it)->SetEnabledBy((*it)->GetEnabledBy() + 1);
			}
		}
	}
}

void dcSystem::dumpNoCLoadGraphFile() {
	ofstream f(params.getOutputFolder() + "/nocLoadFile.gv");
	f << "digraph NoCLoad {" << endl;
	for (unsigned int x = 0; x < params.getRows(); x++) {
		for (unsigned int y = 0; y < params.getCols(); y++) {
			int yS = -y;
			f << x << y << "[style=filled, shape=box, fillcolor=gray, label=\""
					<< x << "," << y << "\", pos=\"" << 1.5 * x << ","
					<< 1.5 * yS << "!\"];" << endl;
		}
	}
	double maxPktCout = 0;
	typedef map<int, unsigned int>::const_iterator it_type;
	for (it_type iterator = noc_->routeToNbPkts.begin();
			iterator != noc_->routeToNbPkts.end(); iterator++) {
		if (iterator->second > maxPktCout) {
			maxPktCout = iterator->second;
		}
	}
	for (unsigned int x = 0; x < params.getRows(); x++) {
		for (unsigned int y = 0; y < params.getCols(); y++) {
			// Right edge
			if (x < params.getRows() - 1) {
				int route = pairing_function(pairing_function(y, x),
						pairing_function(y, x + 1));
				double load = noc_->routeToNbPkts[route] / maxPktCout;
				f << x << y << "->" << (x + 1) << y << "[label=\""
						<< setprecision(2) << load << "\"];" << endl;
			}
			// Left edge
			if (x >= 1) {
				int route = pairing_function(pairing_function(y, x),
						pairing_function(y, x - 1));
				double load = noc_->routeToNbPkts[route] / maxPktCout;
				f << x << y << "->" << (x - 1) << y << "[label=\""
						<< setprecision(2) << load << "\"];" << endl;
			}
			// Up edge
			if (y >= 1) {
				int route = pairing_function(pairing_function(y, x),
						pairing_function(y - 1, x));
				double load = noc_->routeToNbPkts[route] / maxPktCout;
				f << x << y << "->" << x << (y - 1) << "[label=\""
						<< setprecision(2) << load << "\"];" << endl;
			}
			// Bottom edge
			if (y < params.getRows() - 1) {
				int route = pairing_function(pairing_function(y, x),
						pairing_function(y + 1, x));
				double load = noc_->routeToNbPkts[route] / maxPktCout;
				f << x << y << "->" << x << (y + 1) << "[label=\""
						<< setprecision(2) << load << "\"];" << endl;
			}
		}
	}
	f << "}";
	f.close();
}

void dcSystem::dumpTaskAndRunnableGraphFile() {
	ofstream dcGraphDotFile(params.getOutputFolder() + "/dcRunGraphFile.gv");
	dcGraphDotFile << "digraph Runnable {" << endl;
	dcGraphDotFile << "\tcompound=true;" << endl;
	unsigned int i = 0;
	for (std::vector<dcTask *>::iterator it = tasks.begin(); it != tasks.end();
			++it) {
		dcGraphDotFile << "\tsubgraph cluster" << i << " {" << endl;
		dcRunnable *run = (*it)->GetRunnables();
		while (run != NULL) {
			dcGraphDotFile << "\t\t" << run->GetName();
			dcGraphDotFile << "[label=\"";
			dcGraphDotFile << run->GetName();
			dcGraphDotFile << "\\nWave id=" << hex << run->GetWaveID();
			dcGraphDotFile << "\"];" << endl;
			dcRunnableEdge *edge = run->GetEdges();
			while (edge != NULL) {
				if (edge->GetType() == 1) {
					dcGraphDotFile << "\t\t" << run->GetName() << " -> "
							<< edge->GetConnectTo()->GetName() << ";" << endl;
				}
				edge = edge->GetNext();
			}
			run = run->GetNext();
		}
		i++;
		dcGraphDotFile << "\t}" << endl;
	}
	dcGraphDotFile << "}";
	dcGraphDotFile.close();
}

void dcSystem::dumpTaskGraphFile() {

	FILE* dcGraphDotFile = fopen(
			(params.getOutputFolder() + "/dcTasksGraphFile.gv").c_str(), "w+");
	fputs("digraph application {\n", dcGraphDotFile);
	for (std::vector<dcTask *>::iterator it = tasks.begin(); it != tasks.end();
			++it) {
		fputs((*it)->GetName().c_str(), dcGraphDotFile);
		dcActEvent* event = (*it)->GetActEvent();
		if (event != NULL) {
			if (event->GetType() == "stimuli:Periodic") {
				dcPeriodicEvent* periodic = static_cast<dcPeriodicEvent*>(event);
				pair<int, string> recurrence = periodic->GetRecurrence();
				fputs("[color=red,fontcolor=red,label=\"", dcGraphDotFile);
				fputs((*it)->GetName().c_str(), dcGraphDotFile);
				fprintf(dcGraphDotFile, "\\nPeriod=%d%s", recurrence.first,
						recurrence.second.c_str());
				fputs("\"]", dcGraphDotFile);
			} else if (event->GetType() == "stimuli:Sporadic") {
				dcSporadicEvent* sporadic = static_cast<dcSporadicEvent*>(event);
				double lowerBound = sporadic->GetLowerBound();
				double upperBound = sporadic->GetUpperBound();
				fputs("[color=blue,fontcolor=blue,label=\"", dcGraphDotFile);
				fputs((*it)->GetName().c_str(), dcGraphDotFile);
				fprintf(dcGraphDotFile, "\\nSporadic=%0.2f,%0.2f", lowerBound,
						upperBound);
				fputs("\"]", dcGraphDotFile);
			}
		}
		fputs(";\n", dcGraphDotFile);
	}
	for (std::vector<dcTask *>::iterator it = tasks.begin(); it != tasks.end();
			++it) {
		dcTaskEdge * edge = (*it)->GetEdges();
		while (edge != NULL) {
			if (edge->GetType()) {
				fputs((*it)->GetName().c_str(), dcGraphDotFile);
				fputs(" -> ", dcGraphDotFile);
				fputs(edge->GetConnectTo()->GetName().c_str(), dcGraphDotFile);
				fputs(";\n", dcGraphDotFile);
			}
			edge = edge->GetNext();
		}
	}
	fputs("}", dcGraphDotFile);
	fclose(dcGraphDotFile);
}

/**
 * This SC_METHOD is called each time a mode switch occur
 * using dynamic sensitivity
 */
void dcSystem::modeSwitcher_thread() {
	vector<mode_t>::size_type modIdx = 0;
	while (true) {
		unsigned long int nowInNano = sc_time_stamp().value() * 1E-3;
		mappingHeuristic->switchMode(nowInNano, modes.at(modIdx).file);
		assert(
				modes.at(modIdx).time == nowInNano
						&& "Invalid time in modeSwitcher_thread");
		if (modIdx + 1 < modes.size()) {
			unsigned long int waitTime = modes.at(modIdx + 1).time - nowInNano;
			modIdx++;
			wait(waitTime, SC_NS);
		} else {
			stopSimu_event.notify();
			break;
		}
	}
}

/**
 * SC_METHOD that release all independent runnables.
 * This method is called first at time zero and then on each
 * iteration_event notification.
 */
void dcSystem::nonPeriodicIndependentRunnablesReleaser_method() {
	vector<dcRunnable *> runs;
	if (params.dontHandlePeriodic()) {
		runs = applicaton->GetIndependentRunnables(taskGraph);
	} else {
		runs = applicaton->GetIndependentNonPeriodicRunnables(taskGraph);
	}
	if (runs.size() == 0) {
		cerr << params.getAppXml()
				<< " doesn't contain any independent runnable to start, please check it !"
				<< endl;
		exit(-1);
	}
	int cpt = 0;
	for (std::vector<dcRunnable *>::iterator it = runs.begin();
			it != runs.end(); ++it) {
		releaseRunnable(*it);
		cpt++;
	}
}

/**
 * SystemC thread used to release periodic runnables.
 * This thread is triggered at initialization time and then dynamically
 * computes its next occurrence.
 */
void dcSystem::periodicRunnablesReleaser_thread() {

	// Only used in periodic handling case
	if (params.dontHandlePeriodic()) {
		return;
	}

	vector<int>::size_type nbPeriodicRunnables =
			periodicAndSporadicRunnables.size();
	vector<unsigned long int> remainingTimeBeforeRelease(nbPeriodicRunnables);
	for (vector<int>::size_type i = 0; i < nbPeriodicRunnables; ++i) {
		dcRunnable *runnable = periodicAndSporadicRunnables.at(i);
		remainingTimeBeforeRelease[i] = runnable->GetOffsetInNano();
	}

	while (true) {

		// Stop the simu if hyper period reached and we are not using mode switch
		if (simulationEnd == 0 && !params.dontHandlePeriodic()
				&& hyperPeriod > 0
				&& (sc_time_stamp().value() / 1E3) >= hyperPeriod) {
			stopSimu_event.notify();
			return;
		}

		unsigned long int waitTime = ULONG_MAX;
		for (vector<int>::size_type i = 0; i < nbPeriodicRunnables; ++i) {
			if (remainingTimeBeforeRelease[i] == 0) {
				dcRunnable *runnable = periodicAndSporadicRunnables.at(i);
				releaseRunnable(runnable);
				remainingTimeBeforeRelease[i] = runnable->GetPeriodInNano();
			}
			if (remainingTimeBeforeRelease[i] < waitTime) {
				waitTime = remainingTimeBeforeRelease[i];
			}
		}
		for (vector<int>::size_type i = 0; i < nbPeriodicRunnables; ++i) {
			remainingTimeBeforeRelease[i] = remainingTimeBeforeRelease[i]
					- waitTime;
		}
		wait(waitTime, SC_NS);
	}
}

/**
 * SystemC method called once only during initialization.
 */
void dcSystem::labelsMapper_method() {
	for (vector<dcLabel*>::size_type i = 0; i < labels.size(); i++) {
		dcMappingHeuristicI::dcMappingLocation loc = mappingHeuristic->mapLabel(
				labels.at(i)->GetID(), labels.at(i)->GetSize());
		// All the PEs have a local copy of the labels mapping table
		for (unsigned int row(0); row < params.getRows(); ++row) {
			for (unsigned int col(0); col < params.getCols(); ++col) {
				pes[row][col]->labelsMappingTable.push_back(
						std::make_pair(loc, labels.at(i)->GetName()));
			}
		}
	}
}

void dcSystem::runnablesMapper_thread() {

	int appIterations = 0;
	int remainingNbRunnablesToMap = runnables.size();
	for (unsigned int row(0); row < params.getRows(); ++row) {
		for (unsigned int col(0); col < params.getCols(); ++col) {
			pes[row][col]->newRunnableSignal = false;
		}
	}

	// Map runnables until application is "finished"
	while (true) {

		// Wait until a runnable can be executed or we reached hyper period
		if (readyRunnables.empty()) {
			wait();
			continue;
		}

		// Ask the mapping heuristic where to map the current ready runnable
		dcMappingHeuristicI::dcMappingLocation pe =
				mappingHeuristic->mapRunnable(sc_time_stamp().value(),
						readyRunnables.front()->GetID());
		int x = pe.first;
		int y = pe.second;

		// If the PE has completed receiving the previous runnable,
		// map the new one on it
		// ONE clock cycle
		if (!pes[x][y]->newRunnableSignal) {
			runnablesMappingCsvFile << readyRunnables.front()->GetID() << ";"
					<< readyRunnables.front()->GetName() << ";" << x << y
					<< endl;
			nbRunnablesMapped++;
			readyRunnables.front()->SetMappingTime(sc_time_stamp().value());
			pes[x][y]->newRunnable = readyRunnables.front();
			pes[x][y]->newRunnableSignal = true;
			newRunnable_event[x][y].notify();
			readyRunnables.erase(readyRunnables.begin());
			remainingNbRunnablesToMap--;
			if (remainingNbRunnablesToMap == 0) {
				appIterations++;
				remainingNbRunnablesToMap = runnables.size();
			}
			wait(1, SC_NS);
		}

		// Else move the current runnable to the end of the independent queue
		// ONE clock cycle
		else {
			readyRunnables.push_back(readyRunnables.front());
			readyRunnables.erase(readyRunnables.begin());
			wait(1, SC_NS);
		}
	}
}

void dcSystem::parseModeFile(string file) {
	std::ifstream infile(file);
	std::string line;
	while (std::getline(infile, line)) {
		istringstream is(line);
		string timeString;
		string modeName;
		string modeFile;
		getline(is, timeString, ';');
		getline(is, modeName, ';');
		getline(is, modeFile, ';');
		string::size_type sz;
		unsigned long int timeInNano = stod(timeString, &sz) * 1E9;
		mode_t mode { timeInNano, modeName, modeFile };
		modes.push_back(mode);
	}
}

/**
 * SystemC thread that receive packets from the processing elements
 * and forward them to the NoC.
 * TODO: remove the dcSystem layer between cores and NoC
 */
void dcSystem::pktFromPeReceiver_cthread() {

	for (unsigned int row(0); row < params.getRows(); ++row) {
		for (unsigned int col(0); col < params.getCols(); ++col) {
			trReady[row][col].write(false);
		}
	}
	wait();

	while (true) {

		// Copy packets from PEs in a local vector
		// 1 clock cycle
		vector<Packet> intermediateQ;
		for (unsigned int x(0); x < params.getRows(); ++x) {
			for (unsigned int y(0); y < params.getCols(); ++y) {
				if (newPktFromPe[x][y].read()) {
					Packet pkt = pktsFromPe[x][y].read();
					intermediateQ.push_back(pkt);
					trReady[x][y].write(false); // indicates the PE that dcSystem has received the pkt
				}
			}
		}
		wait(1);

		// Control injection rate.
		while ((nbPacketSendInNoc - nbpacketReceivedFromNoc)
				> (params.getRows() * params.getCols() / 2)) {
			wait();
		}

		// Send the packets into the NoC
		// 1 clock cycle
		for (vector<Packet>::size_type i = 0; i < intermediateQ.size(); i++) {
			commIn.write(intermediateQ.at(i));
			nbPacketSendInNoc++;
			wait(SC_ZERO_TIME);
		}
		wait();

		// Say to PEs that we can receive again packets
		// 1 clock cycle
		for (unsigned int row(0); row < params.getRows(); ++row) {
			for (unsigned int col(0); col < params.getCols(); ++col) {
				trReady[row][col].write(true);
			}
		}
		wait();

		// Wait for new packets to be sent
		bool w = true;
		for (unsigned int x(0); x < params.getRows(); ++x) {
			for (unsigned int y(0); y < params.getCols(); ++y) {
				if (newPktFromPe[x][y].read()) {
					w = false;
					break;
				}
			}
			if (!w) {
				break;
			}
		}
		if (w) {
			wait(packetToSend_event);
		}
	}
}

/**
 * Receive packets from NoC and forward them to cores
 * TODO: remove the dcSystem layer between cores and NoC
 */
void dcSystem::pktToPeDeliverer_method() {
	Packet temp = commOut;
	nbpacketReceivedFromNoc++;
	packet_local_.push_back(temp);
	while (!packet_local_.empty()) {
		pair<unsigned int, unsigned int> delivered_destination =
				packet_local_.front().get_destination();
		pktsToPe[delivered_destination.first][delivered_destination.second] =
				packet_local_.front();
		packet_local_.erase(packet_local_.begin());
	}
}

void dcSystem::releaseRunnable(dcRunnable *runnable) {
	readyRunnables.push_back(runnable);
	runnableReleased_event.notify();
}

void dcSystem::stopSimu_thread() {

	// TODO: In the case of periodic runnables
	// handling,  wait for all aperiodic ones to be
	// completed

	// Wait for all the packets sent to the NoC to be delivered
	while (nbPacketSendInNoc > nbpacketReceivedFromNoc) {
		wait(commOut.value_changed_event());
	}

	// Dump NoC traces
	dumpNoCLoadGraphFile();
	for (unsigned int row(0); row < params.getRows(); ++row) {
		for (unsigned int col(0); col < params.getCols(); ++col) {
			pes[row][col]->dumpNoCTraces();
		}
	}

	// Get end time
	clock_t end = std::clock();

	// Prints label access results
	ofstream f(params.getOutputFolder() + "/labels.csv");
	f << "PE,";
	f << "Nb bytes for local reads,";
	f << "Nb of local reads,";
	f << "Nb bytes for local writes,";
	f << "Nb of local writes,";
	f << "Nb bytes for remote reads,";
	f << "Nb of remote reads,";
	f << "Nb bytes for remote writes,";
	f << "Nb of remote write,";
	f << "Total computation time" << endl;
	unsigned int nbLocRds = 0;
	unsigned int nbLocWrs = 0;
	unsigned int nbRemRds = 0;
	unsigned int nbRemWrs = 0;
	unsigned long int bytesLocRds = 0;
	unsigned long int bytesLocWrs = 0;
	unsigned long int bytesRemRds = 0;
	unsigned long int bytesRemWrs = 0;
	unsigned long int computationTime = 0;
	for (unsigned int row(0); row < params.getRows(); ++row) {
		for (unsigned int col(0); col < params.getCols(); ++col) {
			f << "PE" << row << col << ",";
			f << pes[row][col]->bytesLocRds << ",";
			f << pes[row][col]->nbLocRds << ",";
			f << pes[row][col]->bytesLocWrs << ",";
			f << pes[row][col]->nbLocWrs << ",";
			f << pes[row][col]->bytesRemRds << ",";
			f << pes[row][col]->nbRemRds << ",";
			f << pes[row][col]->bytesRemWrs << ",";
			f << pes[row][col]->nbRemWrs << ",";
			f << pes[row][col]->computationTime << endl;
			bytesLocRds += pes[row][col]->bytesLocRds;
			bytesLocWrs += pes[row][col]->bytesLocWrs;
			bytesRemRds += pes[row][col]->bytesRemRds;
			bytesRemWrs += pes[row][col]->bytesRemWrs;
			nbLocRds += pes[row][col]->nbLocRds;
			nbLocWrs += pes[row][col]->nbLocWrs;
			nbRemRds += pes[row][col]->nbRemRds;
			nbRemWrs += pes[row][col]->nbRemWrs;
			computationTime += pes[row][col]->computationTime;
		}
	}
	f << "Total Nb bytes for local reads = " << bytesLocRds << endl;
	f << "Total Nb of local reads = " << nbLocRds << endl;
	f << "Total Nb bytes for local writes = " << bytesLocWrs << endl;
	f << "Total Nb of local writes = " << nbLocWrs << endl;
	f << "Total Nb bytes for remote reads = " << bytesRemRds << endl;
	f << "Total Nb of remote reads = " << nbRemRds << endl;
	f << "Total Nb bytes for remote writes = " << bytesRemWrs << endl;
	f << "Total Nb of remote writes = " << nbRemWrs << endl;
	f.close();

	// Print some results in a file for energy estimation
	FILE *Parameters = fopen(
			(params.getOutputFolder() + "/Parameters.txt").c_str(), "w+");
	unsigned long int endTimeInNano = sc_time_stamp().value() / 1E3;
	string timeString = static_cast<ostringstream*>(&(ostringstream()
			<< endTimeInNano))->str();
	float systemFreq = 1.0 / CLOCK_PERIOD;
	std::ostringstream freqVal;
	freqVal << systemFreq;
	string freqString = freqVal.str();
	string parameter_row = static_cast<ostringstream*>(&(ostringstream()
			<< (params.getRows())))->str();
	string parameter_col = static_cast<ostringstream*>(&(ostringstream()
			<< (params.getCols())))->str();
	string s_temp = "Execution time of the application(ns): " + timeString
			+ "\nClock frequency(GHz) : " + freqString + "\nROWS : "
			+ parameter_row + "\nCOLUMNS : " + parameter_col;
	fputs(s_temp.c_str(), Parameters);

	// Print some results on stdout
	cout << " ##Simulation results##" << endl << endl;
	cout << "    Number of runnable instances executed         : "
			<< nbRunnablesCompleted << endl;
	if (params.dontHandlePeriodic()) {
		cout << "    Number of application iterations executed     : "
				<< (nbRunnablesCompleted / runnables.size()) << endl;
	}
	cout << "    Execution time of the application             : "
			<< endTimeInNano << " ns" << endl;
	int nbDeadlineMisses = 0;
	for (unsigned int row(0); row < params.getRows(); ++row) {
		for (unsigned int col(0); col < params.getCols(); ++col) {
			nbDeadlineMisses = nbDeadlineMisses
					+ pes[row][col]->deadlinesMissed;
		}
	}
	cout << "    Number of runnables which missed deadlines    : "
			<< nbDeadlineMisses << endl;
	cout << "    Number of packets exchanged through NoC       : "
			<< (noc_->nbPkts) << endl;
	cout << "    Simulation time                               : "
			<< (double) (end - start) / CLOCKS_PER_SEC << " s" << "\n\n";

	sc_stop();
}

}
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
