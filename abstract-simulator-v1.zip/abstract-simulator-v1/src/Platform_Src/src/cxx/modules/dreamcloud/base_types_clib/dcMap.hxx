////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCMAP_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCMAP_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>
#include <map>

namespace dreamcloud { namespace base_types_clib {

////////////////////
//      USING     //
////////////////////
using std::map;

template<class Key, class T, class Compare = std::less<Key>, class Allocator = std::allocator<T> >
class dcMap
  : public dcBaseType,
    public map<Key,T,Compare,Allocator>
{
public:
  inline dcMap(const Compare& cmp = Compare(), const Allocator& alloc = Allocator()) : map<Key,T,Compare,Allocator>(cmp, alloc) { }
  inline dcMap(const map<Key,T,Compare,Allocator> &map) : map<Key,T,Compare,Allocator>(map) { }

  inline dcBaseType* cpy() const { return new dcMap(*this); }

  virtual inline const dcTypeEnum get_class_type() const { return dcMap::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_map; }

protected:
  // empty

private:
  // empty
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
