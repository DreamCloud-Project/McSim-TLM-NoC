#include "dcSimuParams.hxx"
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdexcept>

std::string getCmdOption(char ** begin, char ** end,
		const std::string & option) {
	char ** itr = std::find(begin, end, option);
	if (itr != end && ++itr != end) {
		return *itr;
	}
	return "";
}

bool cmdOptionExists(char** begin, char** end, const std::string& option) {
	return std::find(begin, end, option) != end;
}

void dcSimuParams::printHelp() {
	std::cerr << "usage is:" << std::endl << binary
			<< " [-d] [-fd] [-h] [-np] [-r] (-a app_file | -f mode_file) -i iterations -m mapping_heuristic -o output_folder -s scheduling_strategy -x rows -y cols"
			<< std::endl;
}

bool dcSimuParams::getHelp() {
	return help;
}

bool dcSimuParams::getSeqDep() {
	return seqDep;
}

bool dcSimuParams::getGenerateWaveforms() {
	return true;
}

bool dcSimuParams::dontHandlePeriodic() {
	return dontHandlePer;
}

bool dcSimuParams::getFullDuplex() {
	return fullDuplex;
}

bool dcSimuParams::getRandomNonDet() {
	return randomNonDet;
}

std::string dcSimuParams::getOutputFolder() {
	return outputFolder;
}

std::string dcSimuParams::getMappingHeuristic() {
	return mappingHeuristic;
}

std::string dcSimuParams::getMappingFile() {
	return mappingFile;
}

std::string dcSimuParams::getSchedulingStrategy() {
	return schedulingStrategy;
}

std::string dcSimuParams::getAppXml() {
	return appXml;
}

std::string dcSimuParams::getModeFile() {
	return modeFile;
}

unsigned int dcSimuParams::getRows() {
	return rows;
}

unsigned int dcSimuParams::getCols() {
	return cols;
}

unsigned int dcSimuParams::getIterations() {
	return its;
}

dcSimuParams::dcSimuParams(int argc, char **argv) {
	binary = argv[0];

	if (cmdOptionExists(argv, argv + argc, "-d")) {
		seqDep = true;
	} else {
		seqDep = false;
	}

	if (cmdOptionExists(argv, argv + argc, "-fd")) {
		fullDuplex = true;
	} else {
		fullDuplex = false;
	}

	if (cmdOptionExists(argv, argv + argc, "-h")) {
		help = true;
	} else {
		help = false;
	}

	if (cmdOptionExists(argv, argv + argc, "-np")) {
		dontHandlePer = true;
	} else {
		dontHandlePer = false;
	}

	if (cmdOptionExists(argv, argv + argc, "-r")) {
		randomNonDet = true;
	} else {
		randomNonDet = false;
	}

	outputFolder = getCmdOption(argv, argv + argc, "-o");
	if (outputFolder.empty()) {
		printHelp();
		exit(-1);
	}
	struct stat info;
	if (stat(outputFolder.c_str(), &info) != 0) {
		std::cerr << "cannot access output folder " << outputFolder
				<< std::endl;
	} else if (!(info.st_mode & S_IFDIR)) {
		std::cerr << "output folder " << outputFolder
				<< " is not a folder but a file" << std::endl;
	}

	mappingHeuristic = getCmdOption(argv, argv + argc, "-m");
	if (mappingHeuristic.empty()) {
		printHelp();
		exit(-1);
	}
	if (mappingHeuristic != "KhalidDC" && mappingHeuristic != "MinComm"
			&& mappingHeuristic != "Static" && mappingHeuristic != "StaticSM"
			&& mappingHeuristic != "ZigZag" && mappingHeuristic != "ZigZagSM"
			&& mappingHeuristic != "3Core") {
		std::cerr << "invalid mapping heuristic: " << mappingHeuristic
				<< std::endl
				<< "  valid ones are KhalidDC, MinComm, Static, StaticSM, ZigZag, ZigZagSM, 3Core"
				<< std::endl;
		exit(-1);
	}
	std::string prefix("Static");
	if (!mappingHeuristic.compare(0, prefix.size(), prefix)) {
		mappingFile = getCmdOption(argv, argv + argc, mappingHeuristic);
		struct stat fileStatus;
		errno = 0;
		if (stat(mappingFile.c_str(), &fileStatus) == -1) {
			if (errno == ENOENT)
				throw(std::runtime_error(
						mappingFile
								+ " does not exist, or path is an empty string."));
			else if ( errno == ENOTDIR)
				throw(std::runtime_error(
						"Mapping file A component of the path is not a directory."));
			else if ( errno == ELOOP)
				throw(std::runtime_error(
						"Mapping file Too many symbolic links encountered while traversing the path."));
			else if ( errno == EACCES)
				throw(std::runtime_error("Mapping file Permission denied."));
			else if ( errno == ENAMETOOLONG)
				throw(std::runtime_error("Mapping file  can not be read."));
		}
	}

	schedulingStrategy = getCmdOption(argv, argv + argc, "-s");
	if (schedulingStrategy.empty()) {
		printHelp();
		exit(-1);
	}
	if (schedulingStrategy != "fcfs" && schedulingStrategy != "prio") {
		std::cerr << "invalid scheduling strategy:" << schedulingStrategy
				<< std::endl << "  valid ones are fcfs and prio" << std::endl;
		exit(-1);
	}

	// Get application or mode file
	appXml = getCmdOption(argv, argv + argc, "-a");
	modeFile = getCmdOption(argv, argv + argc, "-f");
	if (appXml.empty() && modeFile.empty()) {
		printHelp();
		exit(-1);
	}
	if (!appXml.empty() && !modeFile.empty()) {
		printHelp();
		exit(-1);
	}
	if (!appXml.empty() && !std::ifstream(appXml)) {
		std::cerr << "application file " << appXml << " doesn't exist"
				<< std::endl;
		exit(-1);
	} else if (!modeFile.empty()) {
		if (!std::ifstream(modeFile)) {
			std::cerr << "mode file " << modeFile << " doesn't exist"
					<< std::endl;
			exit(-1);
		}
	}

	std::string xString = getCmdOption(argv, argv + argc, "-x");
	if (xString.empty()) {
		printHelp();
		exit(-1);
	}
	rows = std::stoi(xString);

	std::string yString = getCmdOption(argv, argv + argc, "-y");
	if (yString.empty()) {
		printHelp();
		exit(-1);
	}
	cols = std::stoi(yString);

	std::string itString = getCmdOption(argv, argv + argc, "-i");
	if (itString.empty()) {
		printHelp();
		exit(-1);
	}
	its = std::stoi(itString);
}

