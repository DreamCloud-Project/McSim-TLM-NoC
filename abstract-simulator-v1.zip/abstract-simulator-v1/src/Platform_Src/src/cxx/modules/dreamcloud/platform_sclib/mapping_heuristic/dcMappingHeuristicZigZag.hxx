/*
 * dcMappingHeuristic.cxx
 *
 *  Created on: Sep 17, 2015
 *      Author: manu
 */
#ifndef MODULES_DREAMCLOUD_PLATFORM_SCLIB_MAPPING_HEURISTIC_ZIGZAG_HXX_
#define MODULES_DREAMCLOUD_PLATFORM_SCLIB_MAPPING_HEURISTIC_ZIGZAG_HXX_

#include <dreamcloud/platform_sclib/mapping_heuristic/dcMappingHeuristicI.hxx>

#define USE_MIN_COMM false

namespace dreamcloud {
namespace platform_sclib {

class dcMappingHeuristicZigZag: public dcMappingHeuristicI {

public:
	// Mapping functions and type definitions
	dcMappingLocation mapRunnable(unsigned long int time,
			const string& runnableId);
	void runnableMapped(unsigned long int time,
			const string& runnableId);
	dcMappingLocation mapLabel(const string& labelId,
			unsigned int labelSize);
	void switchMode(unsigned long int time, const string& newModeFile);

	// Hardware model functions
	void addCoreType(const string& coreType, double energyMultiplier,
			double switchingPModeTimePenalty,
			double switchingPModeEnergyPenalty, int maxFrequencyInHz,
			map<double, double> voltageToFreq, int voltToFreqLevel);
	void addProcessingCore(const string& name, int x, int y,
			const string& coreType, unsigned int clockRatio,
			unsigned int quartz, unsigned int ticksPerCycle,
			double staticEnergyValue, const string& staticEnergyUnit,
			double energyMultiplier, int pMode);
	void setNocSize(unsigned int NoCXSize, unsigned int NoCYSize);

	// Application model functions
	void setApp(const string& appFile);

	// Platform feedbacks
	void completeRunnable(unsigned long int time, const string& runnableId);
	dcMappingHeuristicZigZag();

private:
	int xRunnable;
	int yRunnable;
	int xLabel;
	int yLabel;
	int NoCXSize;
	int NoCYSize;
};

}
}
#endif
