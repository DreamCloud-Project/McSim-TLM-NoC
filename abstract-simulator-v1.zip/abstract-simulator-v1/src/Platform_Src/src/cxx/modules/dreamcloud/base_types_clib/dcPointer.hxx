////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCPOINTER_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCPOINTER_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>

namespace dreamcloud { namespace base_types_clib {

template<class T>
class dcPointer
  : public dcBaseType
{
public:
  dcPointer(T* t_pointer = 0) : pointer_(t_pointer) { }
  dcPointer(const dcPointer<T> &p) : pointer_(p.pointer_) { }
  ~dcPointer() { }

  T& operator*() { return *pointer_; }
  const T &operator*() const { return *pointer_; }
  T* operator->() { return pointer_; }
  const T* operator->() const { return pointer_; }

  void operator=(T *t_pointer) { pointer_ = t_pointer; }
  void operator=(const dcPointer<T> &pointer) { pointer_ = pointer.pointer_; }

  bool operator==(const T *t_pointer) const { return t_pointer == pointer_; }
  bool operator==(const dcPointer<T> &pointer) const { return pointer.pointer_ == pointer_; }
  bool operator!=(const T *t_pointer ) const { return t_pointer != pointer_; }
  bool operator!=(const dcPointer<T> &pointer ) const { return pointer.pointer_ != pointer_; }

  bool operator<(const dcPointer<T> pointer) const { return pointer.pointer_ < pointer_; }

  T* get_pointer() const { return pointer_; }
  const T* get_const_pointer() const { return pointer_; }

protected:

private:
  T* pointer_;
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
