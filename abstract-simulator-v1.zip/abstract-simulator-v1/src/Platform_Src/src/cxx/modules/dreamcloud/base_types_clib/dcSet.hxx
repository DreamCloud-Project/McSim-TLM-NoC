////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCSET_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCSET_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>
#include <set>

namespace dreamcloud { namespace base_types_clib {

////////////////////
//      USING     //
////////////////////
using std::set;

template<class Key, class Compare = std::less<Key>, class Allocator = std::allocator<Key> >
class dcSet
  : public dcBaseType,
    public set<Key,Compare,Allocator>
{
public:
  inline dcSet(const Compare &cmp = Compare(), const Allocator &alloc = Allocator()) : set<Key,Compare,Allocator>(cmp, alloc) { }
  inline dcSet(const set<Key,Compare,Allocator> &s) : set<Key,Compare,Allocator>(s) { }

  inline dcBaseType* cpy() const { return new dcSet(*this); }

  virtual inline const dcTypeEnum get_class_type() const { return dcSet::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_set; }

protected:
  // empty

private:
  // empty
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
