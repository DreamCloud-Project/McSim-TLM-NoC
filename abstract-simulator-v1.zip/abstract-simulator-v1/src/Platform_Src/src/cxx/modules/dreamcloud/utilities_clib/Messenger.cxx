////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/utilities_clib/Messenger.hxx>
#include <dreamcloud/base_types_clib/dcString.hxx>
#include <dreamcloud/base_types_clib/dcVector.hxx>
#include <map>
#include <vector>
#include <fstream>

////////////////////
//      USING     //
////////////////////
using namespace std;
using namespace dreamcloud::base_types_clib;

namespace dreamcloud { namespace utilities_clib { namespace Messenger {

int dbg_level_ = 0;

string make_prefix_(unsigned int level)
{
  char level_num[4];
  level_num[0] = (level/100 % 10) + '0';
  level_num[1] = (level/10 % 10) + '0';
  level_num[2] = (level % 10) + '0';
  level_num[3] = 0;
  
  size_t lpos = 0;
  string result = string("Debug[#]");
  while ((lpos = result.find('#', lpos)) != result.npos)
    result.replace(lpos, 1, level_num, 3);

  return result;
}

bool is_allowed_(int level)
{
  if (level <= dbg_level_)
    return true;
  return false;
}

void messenger_internal(int level, logTypeEnum type, const string &str2)
{
  string str(str2);       
  ostream &stream(type == MSG_DEBUG ? cout : type == MSG_INFO ? cout : cerr);
  string label = "";

  switch(type)
  {
  case MSG_INFO:
    break;
  case MSG_DEBUG:
    label = make_prefix_(level); 
    if (!label.empty()) label += ": ";
    label += string(level, ' ');
    break; 
  case MSG_WARNING:
    label = "Warning: "; break;
  case MSG_ERROR:
    label = "Error: "; break;
  case MSG_FAILURE:
    label = "Failure: "; break;
  case IGNORE:
    return;
  }
  
  dcVector<dcString> tokens;
  dcString::tokenize(str, tokens, "\n");
  for (dcVector<dcString>::const_iterator it(tokens.begin()); it != tokens.end(); ++it)
  {
    stream << "# " << label;
    stream << *it << endl;
  }
  
  flush(stream);
}

void messenger_(int level, logTypeEnum type, const string &str)
{
  messenger_internal(level, type, str);

  if (type == MSG_FAILURE)
    throw Failure(str);
}
 
}}}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
