////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCBASETYPE_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCBASETYPE_HXX

namespace dreamcloud { namespace base_types_clib {

enum dcTypeEnum
{
  dc_base_type = 1,
  dc_string, dc_int, dc_double, dc_scalable, dc_map, dc_set, dc_vector, dc_container,
  dc_shared_pointer,
  dc_app_base_obj
};

class dcBaseType
{
public:
  virtual ~dcBaseType() { }

  template<class T>
  static inline T *dc_obj_cast(dcBaseType *base)
  {
    return (base->get_class_type() == T::class_type()) ? static_cast<T*>(base) : 0;
  }

  virtual inline dcBaseType* cpy() const { return 0; }
  virtual inline const dcTypeEnum get_class_type() const { return dcBaseType::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_base_type; }

protected: 
  dcBaseType() { }

private:
  // empty
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
