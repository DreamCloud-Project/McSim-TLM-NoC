////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCSTRING_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCSTRING_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>
#include <dreamcloud/base_types_clib/dcVector.hxx>
#include <string>
#include <algorithm>

namespace dreamcloud { namespace base_types_clib {

////////////////////
//      USING     //
////////////////////
using std::string;

class dcString
  : public string,
    public dcBaseType
{
public:

  inline dcString() : string(), dcBaseType() { }
  inline dcString(const string& str) : string(str), dcBaseType() { }
  inline dcString(const char* cstr) : string(cstr), dcBaseType() { }

  static dcString lower_case(const dcString &s)
  {
    dcString result;
    std::transform(s.begin(), s.end(), back_inserter(result), (int(*)(int))std::tolower); 
    return result;
  }

  static dcString upper_case(const dcString &s)
  {
    dcString result;
    std::transform(s.begin(), s.end(), back_inserter(result), (int(*)(int))std::toupper); 
    return result;
  }

  static void tokenize(const dcString &s, dcVector<dcString>& token_vec, const dcString &delim = " \n\t")
  {
    size_type lastPos(s.find_first_not_of(delim, 0)), pos(s.find_first_of(delim, lastPos));
    while (npos != pos || npos != lastPos)
    {
      token_vec.push_back(s.substr(lastPos, pos - lastPos));
      lastPos = s.find_first_not_of(delim, pos);
      pos = s.find_first_of(delim, lastPos);
    }
  }

  inline dcBaseType *cpy() const { return new dcString(*this); }

  virtual inline const dcTypeEnum get_class_type() const { return dcString::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_string; }

protected:
  // empty

private:
  // empty
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
