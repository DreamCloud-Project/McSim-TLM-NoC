/*
 * dcSimuParams.hxx
 *
 *  Created on: Sep 10, 2015
 *      Author: manu
 */

#ifndef MAIN_NOC_PPA_CMAIN_DCSIMUPARAMS_HXX_
#define MAIN_NOC_PPA_CMAIN_DCSIMUPARAMS_HXX_

#include <string>

class dcSimuParams {
public:
	std::string getOutputFolder();
	std::string getMappingHeuristic();
	std::string getMappingFile();
	std::string getSchedulingStrategy();
	std::string getAppXml();
	std::string getModeFile();
	dcSimuParams(int argc, char** argv);
	void printHelp();
	bool getHelp();
	bool getSeqDep();
	bool getFullDuplex();
	bool getGenerateWaveforms();
	bool dontHandlePeriodic();
	bool getRandomNonDet();
	unsigned int getRows();
	unsigned int getCols();
	unsigned int getIterations();
private:
	std::string outputFolder;
	std::string mappingHeuristic;
	std::string mappingFile;
	std::string schedulingStrategy;
	std::string appXml;
	std::string modeFile;
	bool dontHandlePer;
	bool help;
	bool fullDuplex;
	bool randomNonDet;
	bool seqDep;
	unsigned int rows;
	unsigned int cols;
	unsigned int its;
	char* binary;
};



#endif /* MAIN_NOC_PPA_CMAIN_DCSIMUPARAMS_HXX_ */
