////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCINT_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCINT_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>

namespace dreamcloud { namespace base_types_clib {

class dcInt
  : public dcBaseType
{
public:
  inline dcInt(int val = 0) : val_(val) { }
  inline ~dcInt() { }

  dcInt &operator+=(const int val) { val_ += val; return *this; }
  dcInt &operator++() { val_ += 1; return *this; }
  dcInt operator++(int) { dcInt old(val_); val_ += 1; return old; }

  dcInt &operator-=(const int val) { val_ -= val; return *this; }
  dcInt &operator--() { val_ -= 1; return *this; }
  dcInt operator--(int) { dcInt old = val_; val_ -= 1;  return old; }

  dcInt &operator()() { return *this; }
  operator int() const { return val_; }

  inline dcBaseType* cpy() const { return new dcInt( val_ ); }

  virtual inline const dcTypeEnum get_class_type() const { return dcInt::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_int; }

protected:
  // empty

private:
  int val_;
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
