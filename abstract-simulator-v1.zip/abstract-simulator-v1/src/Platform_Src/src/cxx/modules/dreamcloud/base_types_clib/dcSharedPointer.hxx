////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCSHAREDPOINTER_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCSHAREDPOINTER_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>

namespace dreamcloud { namespace base_types_clib {

class dcRefCounter
{
public:
  inline void inc_counter() { ++ref_counter_; }
  inline bool dec_counter() { --ref_counter_; return ref_counter_ == 0; }
  inline int get_counter() const { return ref_counter_; }

protected:
  inline dcRefCounter() : ref_counter_(0) { }

private:
  int ref_counter_;
};

template<class T>
class dcSharedPointer
  : public dcBaseType
{
public:
  inline dcSharedPointer(T* t_pointer = 0) : pointer_(t_pointer) { inc(); }
  inline dcSharedPointer(const dcSharedPointer<T> &sp) : pointer_(sp.pointer_) { inc(); }
  inline ~dcSharedPointer() { dec(); }

  inline void inc() { if (pointer_) pointer_->inc_counter(); }
  inline void dec(){ if (pointer_ && pointer_->dec_counter()) delete pointer_; }
  void reset()
  {
    if (pointer_) { pointer_->dec_counter(); pointer_ = 0; }
  }

  T& operator*() { return *pointer_; }
  const T& operator*() const { return *pointer_; }
  T* operator->() { return pointer_; }
  const T* operator->() const { return pointer_; }

  void operator=(T *t_pointer)
  {
    if (pointer_ == t_pointer) return;
    t_pointer->inc_counter();
    dec();
    pointer_ = t_pointer;
  }

  void operator=(dcSharedPointer<T> shared_ptr)
  {
    if (pointer_ == shared_ptr.pointer_) return;
    shared_ptr.inc();
    dec();
    pointer_ = shared_ptr.pointer_;
  }

  bool operator==(const T *t_pointer) const { return t_pointer == pointer_; }
  bool operator==(const dcSharedPointer<T> &shared_ptr) const { return shared_ptr.pointer_ == pointer_; }
  bool operator!=(const T *t_pointer) const { return t_pointer != pointer_; }
  bool operator!=(const dcSharedPointer<T> &shared_ptr) const { return shared_ptr.pointer_ != pointer_; }

  bool operator<(const dcSharedPointer<T> &shared_ptr) const { return shared_ptr.pointer_ < pointer_; }

  T* get_pointer() const { return pointer_; }
  const T* get_const_pointer() const { return pointer_; }

  virtual inline const dcTypeEnum get_class_type() const { return dcSharedPointer::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_shared_pointer; }

protected:

private:
  T* pointer_;
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
