#include "dcRunnable.h"
#include <climits>

namespace DCApplication {
using namespace std;

dcRunnable::dcRunnable(string n) :
		Name(n), RunEdge(NULL), Next(NULL), RunSource(""), RunDestination(NULL), Tail(
				0) {
}

dcActEvent* dcRunnable::GetActEvent() {
	return ActEvent_;
}

void dcRunnable::SetActEvent(dcActEvent* dcActEventIn) {
	ActEvent_ = dcActEventIn;
}

unsigned long dcRunnable::GetPeriodInNano() {
	unsigned long period = 0;
	dcActEvent* event = GetActEvent();
	if (event != NULL) {
		string eventType = event->GetType();
		if (eventType == "stimuli:Periodic") {
			dcPeriodicEvent* periodic = static_cast<dcPeriodicEvent*>(event);
			pair<int, string> recurrence = periodic->GetRecurrence();
			if (recurrence.second == "ns") {
				period = recurrence.first;
			} else if (recurrence.second == "us") {
				period = recurrence.first * 1E3;
			} else if (recurrence.second == "ms") {
				period = recurrence.first * 1E6;
			} else {
				cerr << "Unit not supported in dcApplication::GetHyperPeriod";
				exit(-1);
			}
		} else if (eventType == "stimuli:Sporadic") {
			dcSporadicEvent* sporadic = static_cast<dcSporadicEvent*>(event);
			// TODO: Handle this properly
			period = sporadic->GetLowerBound();
		}
	}
	return period;
}

unsigned long dcRunnable::GetOffsetInNano() {
	unsigned long offset = 0;
	dcActEvent* event = GetActEvent();
	if (event != NULL) {
		string eventType = event->GetType();
		if (eventType == "stimuli:Periodic") {
			dcPeriodicEvent* periodic = static_cast<dcPeriodicEvent*>(event);
			pair<int, string> offsetPair = periodic->GetOffset();
			if (offsetPair.second == "ns") {
				offset = offsetPair.first;
			} else if (offsetPair.second == "us") {
				offset = offsetPair.first * 1E3;
			} else if (offsetPair.second == "ms") {
				offset = offsetPair.first * 1E6;
			} else {
				cerr << "Unit not supported in dcApplication::GetHyperPeriod";
				exit(-1);
			}
		} else if (eventType == "stimuli:Sporadic") {
			// TODO Handle this properly
			dcSporadicEvent* sporadic = static_cast<dcSporadicEvent*>(event);
			offset = sporadic->GetLowerBound();
		}
	}
	return offset;
}

void dcRunnable::SetName(string NameIn) {
	Name = NameIn;
}

string dcRunnable::GetName() {
	return Name;
}

void dcRunnable::SetEdges(dcRunnableEdge* EdgesIn) {
	RunEdge = EdgesIn;
}

void dcRunnable::SetID(string IDIn) {
	ID = IDIn;
}

string dcRunnable::GetID() {
	return ID;
}

dcRunnableEdge* dcRunnable::GetEdges() {
	return RunEdge;
}

void dcRunnable::SetNext(dcRunnable* NextIn) {
	Next = NextIn;
}

dcRunnable* dcRunnable::GetNext() {
	return Next;
}

string dcRunnable::GetRunSource() {
	return RunSource;
}

void dcRunnable::SetRunSource(string RunSourceIn) {
	RunSource = RunSourceIn;
}

vector<string> dcRunnable::GetRunnableDestination() {
	return RunDestination;
}

void dcRunnable::SetRunnableDestination(vector<string> RunDestinationIn) {
	RunDestination = RunDestinationIn;
}

void dcRunnable::SetTags(dcTag* TagsIn) {
	Tags = TagsIn;
}

dcTag* dcRunnable::GetTags() {
	return Tags;
}

void dcRunnable::SetInstructions(vector<dcInstruction*> InstructionsIn) {
	Instructions = InstructionsIn;
}

void dcRunnable::SetSize(int SizeIn) {
	Size = SizeIn;
}

int dcRunnable::GetSize() {
	return Size;
}

int dcRunnable::GetPriority() {
	return Priority;
}

void dcRunnable::SetPriority(int PriorityIn) {
	Priority = PriorityIn;
}

void dcRunnable::SetPreemption(string PreemptionIn) {
	Preemption = PreemptionIn;
}

string dcRunnable::GetPreemption() {
	return Preemption;
}

vector<dcInstruction*> dcRunnable::GetAllInstructions() {
	return Instructions;
}

vector<string> dcRunnable::GetReleasedTasks() {
	return ReleasedTasks;
}

void dcRunnable::SetReleasedTasks(vector<string> ReleasedTaskIn) {
	ReleasedTasks = ReleasedTaskIn;
}

void dcRunnable::SetOrderedTaskReleased(bool OrderedTaskReleasedIn) {
	OrderedTaskReleased = OrderedTaskReleasedIn;
}

bool dcRunnable::GetOrderedTaskReleased() {
	return OrderedTaskReleased;
}

void dcRunnable::SetRunnableExecutionTime(
		dcRunnableExecutionTime* MyExecutionTimeIn) {
	ExecutionTime = MyExecutionTimeIn;
}

dcRunnableExecutionTime* dcRunnable::GetRunnableExecutionTime() {
	return ExecutionTime;
}

void dcRunnable::SetDeadline(pair<int, string> DeadlineIn) {
	Deadline = DeadlineIn;
}

int dcRunnable::GetDeadlineValue() {
	return Deadline.first;
}

unsigned long int dcRunnable::GetDeadlineValueInNano() {
	if (GetDeadlineUnit() == "s") {
		return GetDeadlineValue() * 1E9;
	} else if (GetDeadlineUnit() == "ms") {
		return GetDeadlineValue() * 1E6;
	} else if (GetDeadlineUnit() == "us") {
		return GetDeadlineValue() * 1E3;
	} else if (GetDeadlineUnit() == "ns") {
		return GetDeadlineValue();
	} else {
		//cerr << "Unsupported deadline unit: " << GetDeadlineUnit() << endl;
		//exit(-1);
		return ULLONG_MAX;
	}
}

string dcRunnable::GetDeadlineUnit() {
	return Deadline.second;
}

void dcRunnable::SetTail(dcRunnable* TailIn) {
	Tail = TailIn;
}

dcRunnable* dcRunnable::GetTail() {
	return Tail;
}

void dcRunnable::SetRunnableID(int IDIn) {
	RunnableID = IDIn;
}

int dcRunnable::GetRunnableID() {
	return RunnableID;
}

void dcRunnable::SetStartTime(unsigned long int x) {
	execution_time_start = x;
}

unsigned long int dcRunnable::GetStartTime() {
	return execution_time_start;
}

void dcRunnable::SetCompletionTime(unsigned long int x) {
	execution_time_completition = x;
}

unsigned long int dcRunnable::GetCompletionTime() {
	return execution_time_completition;
}

void dcRunnable::SetWaveID(int x) {
	waveID = x;
}

int dcRunnable::GetWaveID() {
	return waveID;
}

void dcRunnable::SetMappingTime(unsigned long int x) {
	allocation_time = x;
}

unsigned long int dcRunnable::GetMappingTime() {
	return allocation_time;
}

void dcRunnable::SetCoreReceiveTime(unsigned long int x) {
	core_receive_time = x;
}

unsigned long int dcRunnable::GetCoreReceiveTime() {
	return core_receive_time;
}

vector<dcRunnable*> dcRunnable::GetListOfEnables() {
	vector<dcRunnable*> ListRun;
	dcRunnableEdge* MyRunEdges = GetEdges();
	if (MyRunEdges != NULL) {
		while (MyRunEdges != NULL) {
			if (MyRunEdges->GetType() == 1) {
				ListRun.push_back(MyRunEdges->GetConnectTo());
			}
			MyRunEdges = MyRunEdges->GetNext();
		}
	}

	return ListRun;
}

vector<dcRunnable*> dcRunnable::GetListOfEnablers() {
	vector<dcRunnable*> ListRun;
	dcRunnableEdge* MyRunEdges = GetEdges();
	if (MyRunEdges == NULL) {

	} else {
		while (MyRunEdges != NULL) {
			if (MyRunEdges->GetType() == 0) {
				ListRun.push_back(MyRunEdges->GetConnectTo());
			}
			MyRunEdges = MyRunEdges->GetNext();
		}
	}

	return ListRun;
}

void dcRunnable::SetEnabledBy(int x) {
	enabledBy = x;
}

unsigned int dcRunnable::GetEnabledBy() {
	return enabledBy;
}

vector<string> dcRunnable::getReadLabelsIdsBySize() {
	vector<pair<int, string>> temp_;
	int instructionSize = GetAllInstructions().size();
	for (int i = 0; i < instructionSize; i++) {
		DCApplication::dcInstruction* inst = GetAllInstructions().at(i);
		string instrName = inst->GetName();
		if (instrName == "sw:LabelAccess") {
			dcRemoteAccessInstruction *rinst =
					static_cast<dcRemoteAccessInstruction*>(inst);
			if (!rinst->GetWrite()) {
				dcLabel *l = rinst->GetLabel();
				temp_.push_back(std::make_pair(l->GetSize(), l->GetID()));
			}
		}
	}
	sort(temp_.begin(), temp_.end());
	vector<string> insts;
	for (vector<pair<int, string>>::size_type j = 0; j < temp_.size(); j++) {
		insts.push_back(temp_.at(j).second);
	}
	return insts;
}
}
