////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/platform_sclib/processingElement.hxx>
#include <math.h> 
#include <bitset>
#include <dreamcloud/platform_sclib/NoC_PPA/nocInterconnect.hxx>
#include <dreamcloud/base_types_clib/dcVector.hxx>
#include <dreamcloud/utilities_clib/Messenger.hxx>
#include <dreamcloud/utilities_clib/Math.hxx>

////////////////////
//      USING     //
////////////////////
using namespace std;
using namespace dreamcloud::base_types_clib;
using namespace dreamcloud::utilities_clib::Messenger;
using namespace dreamcloud::utilities_clib::Math;

namespace dreamcloud {
namespace platform_sclib {

/**
 * Add the given runnable execution element to th ready list.
 * This function preserve ready runnables list order according
 * to the priority of the runnable execution element.
 */
void processingElement::addReadyRunnable(runnableExecElement runnableExecElem) {
	readyRunnables.insert(readyRunnables.begin(), runnableExecElem);
	std::sort(readyRunnables.begin(), readyRunnables.end(),
			[](const runnableExecElement &left, const runnableExecElement &right)
			{
				return left.first < right.first;
			});
}

/**
 * SystemC method sensitive to the writeAccessToNoCTraces signal that
 * dump all the NoC traffic strings recorded during simulation into a file.
 * This signal is raised to true by dcSystem at the end of the simu.
 * TODO: do the writing in the output file during simulation as for other files
 */
void processingElement::dumpNoCTraces() {
	for (vector<char*>::size_type i = 0; i < nocTrafficStrings.size(); i++) {
		fputs(nocTrafficStrings.at(i), nocTrafficCsvFile);
	}
}

/**
 * Execute the given constant number of instructions by
 * waiting. Also log information for energy model.
 */
void processingElement::executeInstructionsConstant(dcInstruction *inst,
		dcRunnable *run, int instructionId) {
	dcExecutionCyclesConstantInstruction* einst =
			static_cast<dcExecutionCyclesConstantInstruction*>(inst);
	wait(einst->GetValue(), SC_NS);
	string exeInstS = run->GetName() + " ," + std::to_string(instructionId)
			+ " ," + std::to_string(einst->GetValue()) + "\n";
	computationTime += einst->GetValue();
	const char* exeInstS_const = exeInstS.c_str();
	fputs(exeInstS_const, instsCsvFile);
}

/**
 * Execute the given deviation number of instructions by
 * waiting. Also log information for energy model.
 */
void processingElement::executeInstructionsDeviation(dcInstruction *inst,
		dcRunnable *run, int instructionId) {
	dcExecutionCyclesDeviationInstruction* einst =
			static_cast<dcExecutionCyclesDeviationInstruction*>(inst);
	double UpperBound = 0.0;
	double LowerBound = 0.0;
	if (einst->GetUpperBoundValid()) {
		UpperBound = einst->GetUpperBound();
	}
	if (einst->GetLowerBoundValid()) {
		LowerBound = einst->GetLowerBound();
	}
	std::uniform_int_distribution<> distr(LowerBound, UpperBound);
	int compute_duration = distr(gen);
	wait(compute_duration, SC_NS);
	computationTime += compute_duration;
	string exeInstS = run->GetName() + " ," + std::to_string(instructionId)
			+ " ," + std::to_string(compute_duration) + "\n";
	const char* exeInstS_const = exeInstS.c_str();
	fputs(exeInstS_const, instsCsvFile);
}

void processingElement::executeRemoteLabelRead(dcRemoteAccessInstruction *rinst,
		dcRunnable *run, int x, int y, int instructionId) {

	// Create packet representing read request
	pktQElement temp_Packet;
	temp_Packet.priority = run->GetPriority();
	temp_Packet.readRequestId = nextReadRequestId++; // ID used to identified when we'll receive answer packtes to wich requests they correspond
	temp_Packet.source = make_pair(x_PE, y_PE);
	temp_Packet.destination = make_pair(x, y);
	temp_Packet.write = false;
	temp_Packet.readResponse = false;
	temp_Packet.requestedSize = (int) (ceil(
			double(rinst->GetLabel()->GetSize())
					/ double(8 * PACKET_SIZE_IN_BYTES))); // Packets ;
	temp_Packet.write_rq_ID = 0;
	temp_Packet.write_rq_size = 0;
	temp_Packet.write_request_ID = 0;
	nbRemRds++;
	bytesRemRds += rinst->GetLabel()->GetSize();

	// Put the runnable in the blocked list
	// and remove it from the ready list
	runnableBlockedOnRemoteRead blockedOnRemoteRead;
	responsePackets waitingParameters;
	runnableExecStatus preemptedRStructure = std::make_pair(instructionId + 1,
			run);
	runnableExecElement preempted = std::make_pair(temp_Packet.readRequestId,
			preemptedRStructure);
	waitingParameters.first = temp_Packet.destination;
	waitingParameters.second = 0;
	blockedOnRemoteRead.first = waitingParameters;
	blockedOnRemoteRead.second.first = temp_Packet.requestedSize;
	blockedOnRemoteRead.second.second = preempted;
	runnablesBlockedOnRemoteRead.push_back(blockedOnRemoteRead);
	removeReadyRunnable(run);

	// Notify packet_creater()
	localPktsOut.push_back(temp_Packet);
	sendPacket_event.notify();

	// Sending a packet has a cost of 32 cycles for now:
	// 1 clock cycle for each flit of the packet
	wait(PACKET_SIZE_IN_BYTES, SC_NS);

	// Log runnable block in VCD file
	if (params.getGenerateWaveforms()) {
		unsigned long int nowInNano = sc_time_stamp().value() * 1E-3;
		*runnablesVcdFile << "#" << nowInNano << endl;
		*runnablesVcdFile << VCD_12_UNDEF << " " << VCD_ACTIVE_RUN_ID << x_PE
				<< y_PE << endl;
		*runnablesVcdFile << "1" << VCD_SUSPENDED_ON_REQUEST << x_PE << y_PE
				<< endl;
	}
}

void processingElement::executeRemoteLabelWrite(
		dcRemoteAccessInstruction *rinst, dcRunnable *run, int writeRequestId,
		int x, int y) {
	int number_of_Packets = (int) (ceil(
			double(rinst->GetLabel()->GetSize())
					/ double(8 * PACKET_SIZE_IN_BYTES)));
	nbRemWrs++;
	bytesRemWrs += rinst->GetLabel()->GetSize();
	for (int pkts = 0; pkts < number_of_Packets; pkts++) {
		pktQElement temp_Packet;
		temp_Packet.priority = run->GetPriority();
		temp_Packet.source = make_pair(x_PE, y_PE);
		temp_Packet.destination = make_pair(x, y);
		temp_Packet.write = true;
		temp_Packet.readResponse = false;
		temp_Packet.requestedSize = 0;
		temp_Packet.write_rq_ID = pkts;
		if (pkts == 0) {
			temp_Packet.write_rq_size = number_of_Packets;
		} else {
			temp_Packet.write_rq_size = 0;
		}
		temp_Packet.write_request_ID = writeRequestId;
		localPktsOut.push_back(temp_Packet);
		wait(PACKET_SIZE_IN_BYTES, SC_NS);
	}

	// Notify packet_creater()
	sendPacket_event.notify();
}

/**
 * SC_METHOD sensitive to the packet_in port which
 * is connected to an sc_buffer. It handles the
 * received packets according to 3 situations:
 *
 *   1 Remote write from other PE
 *   2 Remote read from other PE
 *   3 Answer to a remote read originated from this PE
 *
 *   In the situation number 2, some packets need to be sent back
 *   to the requester.
 *
 */
void processingElement::pktReceiver_method() {

	Packet p = packet_in.read();
	p.set_delivery_time();

	// We receive a request for a write to this PE from a remote PE
	// TODO: ensure that we can remove this case
	if (p.isWrite()) {

		if (p.get_write_rq_ID() == 0 && p.get_write_rq_size() > 0) {
			writeRequests_in_process temp;
			temp.first = p.get_write_request_ID();
			temp.second.first = std::make_pair(p.get_source().first,
					p.get_source().second);
			temp.second.second.first = 1; //  1 because current packet itself is the first packet
			temp.second.second.second = p.get_write_rq_size();
			writeRequests.push_back(temp);
			if (p.get_write_rq_size() == 1) {
				goto wr_only_one;
			}
		} else {
			wr_only_one: vector<writeRequests_in_process>::iterator writeRequests_Iterator;
			writeRequests_Iterator =
					std::find_if(writeRequests.begin(), writeRequests.end(),
							[&p](const writeRequests_in_process& pair)
							{
								return ((pair.first == p.get_write_request_ID()) &&
										(pair.second.first.first == p.get_source().first) &&
										(pair.second.first.second == p.get_source().second));
							});
			if (writeRequests_Iterator != writeRequests.end()) {
				if (p.get_write_rq_size() == 0 && (p.get_write_rq_ID() > 0)
						&& (p.get_write_request_ID()
								== writeRequests_Iterator->first))
					(writeRequests_Iterator->second.second.first)++;
			}
		}
	}

	// We receive a read from a remote PE
	// we must send back the response
	else if (!p.isWrite() && !p.isReadResponse()) {
		int number_of_Packets = p.get_requestedSize();
		for (int pkts = 0; pkts < number_of_Packets; pkts++) {
			pktQElement pktElem;
			pktElem.priority = p.get_priority();
			pktElem.readRequestId = p.get_read_request_id();
			pktElem.source = p.get_destination();
			pktElem.destination = p.get_source();
			pktElem.write = false;
			pktElem.requestedSize = 0;
			pktElem.readResponse = true;
			localPktsOut.push_back(pktElem);
		}
		// Notify packet_creater()
		sendPacket_event.notify();
	}

// We receive a response from a previous remote read originated from this PE
// We must move the runnable concerned by this read from the "blocked on remote read"
// runnables list to the "ready" runnables one.
	else if (!p.isWrite() && p.isReadResponse()) {
		std::pair<int, int> source = p.get_source();
		int readRequestId = p.get_read_request_id();
		vector<runnableBlockedOnRemoteRead>::iterator it;
		it =
				std::find_if(runnablesBlockedOnRemoteRead.begin(),
						runnablesBlockedOnRemoteRead.end(),
						[&source, &readRequestId](const runnableBlockedOnRemoteRead& pair)
						{
							return ((pair.first.first == source) && (pair.second.second.first == readRequestId));
						});

		// If this PE doesn't have a runnable blocked on the remote read
		if (it == runnablesBlockedOnRemoteRead.end()) {
			cerr << " PE" << x_PE << y_PE
					<< " received a read response to NOBODY :-( with request ID = "
					<< readRequestId << endl;
			exit(-1);
		}

		// We receive a new packet for the remote read
		// If all the packets have been received, then we can
		// unblock the runnable.
		(it->first.second)++;
		if (it->first.second == it->second.first) {
			addReadyRunnable(it->second.second);
			runnablesBlockedOnRemoteRead.erase(it);
			newRunnable_event->notify();
		}
	}
	string sPacket = p.to_str();
	const char *cstr = sPacket.c_str();
	char* sPacketBuff = new char[(sPacket.length()) + 1];
	strcpy(sPacketBuff, cstr);
	nocTrafficStrings.push_back(sPacketBuff);
}

/**
 * This SC_THREAD sends packet for remote read
 * and remote write request. It's sensitive
 * to the sendPacket_event event which is
 * notified immediately by the runnableExecuter
 * in 3 cases:
 *
 * 1- This core executes a remote read
 * 2- This core executes a remote write
 * 3- This core answers to a remote read from another core
 */
void processingElement::pktSender_thread() {

	while (true) {

		// We can have several packets to send
		// when we reply to a remote read request
		// or when we reply to a remote request AND
		// this core is making a remote request
		// So we send all of them
		while (!localPktsOut.empty()) {

			// Convert the local packet to a one for the NoC
			// TODO: why do we need another packet class ?
			pktQElement localPkt = localPktsOut.front();
			Packet nocPkt;
			nocPkt.set_priority(localPkt.priority);
			nocPkt.set_read_request_id(localPkt.readRequestId);
			nocPkt.set_source(localPkt.source);
			nocPkt.set_destination(localPkt.destination);
			nocPkt.set_rd_wr(localPkt.write);
			nocPkt.set_requestedSize(localPkt.requestedSize);
			nocPkt.set_req_resp(localPkt.readResponse);
			nocPkt.set_writeSize(localPkt.writeSize);
			nocPkt.set_write_rq_ID(localPkt.write_rq_ID);
			nocPkt.set_write_rq_size(localPkt.write_rq_size);
			nocPkt.set_write_request_ID(localPkt.write_request_ID);
			nocPkt.set_injection_time();

			// Wait for dcSystem to be able to receive a packet
			while (!canReceivePkt_signal.read()) {
				wait(CLOCK_PERIOD, SC_NS);
			}

			// Send the packet to dcSystem
			packet_out.write(nocPkt);
			newPacket_signal.write(true);
			packetToSend_event->notify();

			// Wait for dcSystem ack
			while (canReceivePkt_signal.read()) {
				wait(CLOCK_PERIOD, SC_NS);
			}

			// The packet has been sent
			newPacket_signal.write(false);
			localPktsOut.erase(localPktsOut.begin());
		}
		wait(); // wait next event
	}
}

/**
 * SystemC thread that execute an instruction of the current
 * runnable and then check for preemption.
 */
void processingElement::runnableExecuter_thread() {

	int writeRequestId = 0;

	while (true) {

		// Wait for runnables from dcSystem
		if (readyRunnables.empty() && !newRunnableSignal) {
			wait(*newRunnable_event);
		}

		// If a new runnable has been sent during the execution of the last instruction
		// Put it in the ready list
		// ONE clock cycle
		if (newRunnableSignal) {
			runnableExecStatus execStatus = std::make_pair(0, newRunnable);
			int prio;
			if (sched == PRIO) {
				prio = newRunnable->GetPriority();
			} else if (sched == FCFS) {
				prio = newRunnable->GetMappingTime();
			}
			newRunnable->SetCoreReceiveTime(sc_time_stamp().value());
			runnableExecElement execElement = std::make_pair(prio, execStatus);
			addReadyRunnable(execElement);

			// Log runnable preemption in VCD file
			unsigned long int nowInNano = sc_time_stamp().value() * 1E-3;
			if (params.getGenerateWaveforms()) {
				if (readyRunnables.size() > 1
						&& readyRunnables.front().second.second->GetID()
								== newRunnable->GetID()) {
					*runnablesVcdFile << "#" << nowInNano << endl;
					*runnablesVcdFile << "1" << VCD_PREEMPTION << x_PE << y_PE
							<< endl;
				}
			}

			newRunnableSignal = false;
			wait(1, SC_NS);
		}

		// Choose the runnable with the highest priority among ready ones
		// Operation in ZERO clock cycle
		runnableExecElement execElem = readyRunnables.front();
		runnableExecStatus execStatus = execElem.second;
		dcRunnable *currentRunnable = execStatus.second;
		unsigned int instructionId = execStatus.first;
		unsigned int nbInstructions =
				currentRunnable->GetAllInstructions().size();
		bool blockedOnRemoteRead = false;

		// Move to next instruction for next time this runnable will be executed
		readyRunnables.front().second.first++;

		// If the next instruction to execute exists.
		// This checks is required because when we block a runnable
		// on a remote read and its the last instruction, when we unblock it
		// we are above the last instruction
		if (instructionId < nbInstructions) {
			dcInstruction* inst = currentRunnable->GetAllInstructions().at(
					instructionId);
			string instrName = inst->GetName();
			unsigned long int nowInPico = sc_time_stamp().value();
			if (instructionId == 0) {
				currentRunnable->SetStartTime(nowInPico);
			}

			// Log runnable activation in VCD file
			if (params.getGenerateWaveforms()) {
				std::bitset<12> binId(currentRunnable->GetWaveID());
				*runnablesVcdFile << "#" << (nowInPico * 1E-3) << " b" << binId
						<< " " << VCD_ACTIVE_RUN_ID << x_PE << y_PE << endl;
			}

			// Label accesses
			if (instrName == "sw:LabelAccess") {

				// Search where is the label
				dcRemoteAccessInstruction *rinst =
						static_cast<dcRemoteAccessInstruction*>(inst);
				string labelName = rinst->GetLabel()->GetName();
				vector<std::pair<std::pair<int, int>, string> >::iterator it;
				it =
						std::find_if(labelsMappingTable.begin(),
								labelsMappingTable.end(),
								[&labelName](const std::pair< std::pair<int, int>, std::string >& pair)
								{
									return pair.second == labelName;
								});
				int destX = it->first.first;
				int destY = it->first.second;

				// Local read and write accesses
				// ONE clock cycle per byte
				if ((x_PE == destX) && (y_PE == destY)) {
					int localAccessSize = (int) (ceil(
							double(rinst->GetLabel()->GetSize()) / double(8)));
					wait(localAccessSize, SC_NS);
					if (rinst->GetWrite()) {
						nbLocWrs++;
						bytesLocWrs += rinst->GetLabel()->GetSize();
					} else {
						nbLocRds++;
						bytesLocRds += rinst->GetLabel()->GetSize();
					}
				}

				// Remote write: sent packets according to the size of the label
				// nbPackets * PACKET_SIZE clock cycles
				else if (rinst->GetWrite()) {
					executeRemoteLabelWrite(rinst, currentRunnable,
							writeRequestId, destX, destY);
					writeRequestId++;
				}

				// Remote read: send one packet including information allowing
				// receiver to send response back
				// PACKET_SIZE clock cycles
				else if (!rinst->GetWrite()) {
					executeRemoteLabelRead(rinst, currentRunnable, destX, destY,
							instructionId);
					blockedOnRemoteRead = true;
				}
			} // End label access

			// Instruction constant
			else if (instrName == "sw:InstructionsConstant") {
				executeInstructionsConstant(inst, currentRunnable,
						instructionId);
			} else if (instrName == "sw:InstructionsDeviation") {
				executeInstructionsDeviation(inst, currentRunnable,
						instructionId);
			}
		} // End if instructionID < nbInstructions

		// Check if runnable is completed
		if (!blockedOnRemoteRead && (instructionId >= nbInstructions - 1)) {

			// Log runnable info in CSV file
			currentRunnable->SetCompletionTime(sc_time_stamp().value());
			unsigned long int runnableExecutionTime =
					currentRunnable->GetCompletionTime()
							- currentRunnable->GetCoreReceiveTime();
			(*runnablesCsvFile) << "PE" << x_PE << y_PE << ";";
			(*runnablesCsvFile) << currentRunnable->GetName() << ";";
			(*runnablesCsvFile) << currentRunnable->GetPriority() << ";";
			(*runnablesCsvFile) << (currentRunnable->GetMappingTime() / 1E3)
					<< ";";
			(*runnablesCsvFile) << (currentRunnable->GetStartTime() / 1E3)
					<< ";";
			(*runnablesCsvFile) << (currentRunnable->GetCompletionTime() / 1E3)
					<< ";";
			(*runnablesCsvFile) << (runnableExecutionTime / 1E3) << ";";
			(*runnablesCsvFile)
					<< (currentRunnable->GetDeadlineValueInNano() / 1E3) << ";";
			(*runnablesCsvFile)
					<< (currentRunnable->GetDeadlineValueInNano()
							- (runnableExecutionTime / 1E3)) << ";" << endl;

			// Log runnable complete in VCD file
			unsigned long int nowInNano = sc_time_stamp().value() * 1E-3;
			if (params.getGenerateWaveforms()) {
				*runnablesVcdFile << "#" << nowInNano << endl;
				*runnablesVcdFile << VCD_12_UNDEF << " " << VCD_ACTIVE_RUN_ID
						<< x_PE << y_PE << endl;
				*runnablesVcdFile << "1" << VCD_RUNNABLE_COMPLETED << x_PE
						<< y_PE << endl;
			}

			// Check deadline miss
			if (runnableExecutionTime * 1E-3
					> currentRunnable->GetDeadlineValueInNano()) {
				deadlinesMissed++;
				if (params.getGenerateWaveforms()) {
					*runnablesVcdFile << "1" << VCD_DEADLINE_MISSED << x_PE
							<< y_PE << endl;
				}
			}

			// Add the completed runnable to completed queue and remove it from ready one
			completedRunnableIDs.push_back(currentRunnable->GetID());
			(*runnableCompleted_event).notify(SC_ZERO_TIME);
			removeReadyRunnable(currentRunnable);
		}
	}
}

void processingElement::removeReadyRunnable(dcRunnable *runnable) {
	vector<runnableExecElement>::iterator toRemove = std::find_if(
			readyRunnables.begin(), readyRunnables.end(),
			[&runnable](runnableExecElement& elem)
			{
				return elem.second.second == runnable;
			});
	if (toRemove == readyRunnables.end()) {
		cerr << "ERORRRR " << runnable->GetName() << " not found" << endl;
		exit(-1);
	}
	readyRunnables.erase(toRemove);
}

}
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
