#ifndef DREAMCLOUD__UTILITIES_CLIB__DISTRIBUTION_HXX
#define DREAMCLOUD__UTILITIES_CLIB__DISTRIBUTION_HXX

namespace dreamcloud {
namespace utilities_clib {
namespace Distribution {

}

typedef struct distributionParameters {
	//For periodic runnables
	bool periodic_runnable = false;
	int periodic_period = 0;

	//For sporadic runnables
	bool sporadic_runnable = false;
	double sporadic_LowerBound = 0;
	double sporadic_UpperBound = 0;

	bool sporadic_WeibullEstimators = false;
	int sporadic_Xmin = 0;
	int sporadic_Xmax = 0;
	double sporadic_Remain = 0;

	bool sporadic_WeibullParameters = false;
	double sporadic_Lambda = 0;
	double sporadic_Kappa = 0;

	bool sporadic_GuassianDistribution = false;
	double sporadic_mean = 0;
	double sporadic_SD = 0;

	bool sporadic_Boundaries = false;

} distributionParameters;

inline double CreateWeibullEstimators(int Xmin, int Xmax, double Remain) {
	Remain /= 1000;	//since in permille
	Remain = 1 - Remain;
	double p1 = 0.01;	//low probability value - P(X<lowerbound)=p1
	double Shape = (log(-log(1 - Remain)) - log(-log(1 - p1)))
			/ (log(Xmax - Xmin));
	double Scale = Xmin / pow((-log(1 - p1)), (1 / Shape));

	std::random_device rd; // obtain a random number from hardware
	std::mt19937 seed(rd()); // seed the generator
	std::weibull_distribution<double> distribution(Shape, Scale);
	return distribution(seed);
}

inline double CreateWeibullParameters(double Lambda, double Kappa) {
	std::random_device rd; // obtain a random number from hardware
	std::mt19937 seed(rd()); // seed the generator
	std::weibull_distribution<double> distribution(Lambda, Kappa);
	return distribution(seed);
}

inline double CreateGuassianDistribution(double mean, double SD) {
	std::random_device rd; // obtain a random number from hardware
	std::mt19937 seed(rd()); // seed the generator
	std::normal_distribution<double> distribution(mean, SD);
	return distribution(seed);
}

inline int CreateBoundariesDistribution(double LowerBound, double UpperBound) {
	std::random_device rd; // obtain a random number from hardware
	std::mt19937 seed(rd()); // seed the generator
	std::uniform_int_distribution<int> distribution(LowerBound, UpperBound);
	return distribution(seed);
}

}
}
}

#endif
