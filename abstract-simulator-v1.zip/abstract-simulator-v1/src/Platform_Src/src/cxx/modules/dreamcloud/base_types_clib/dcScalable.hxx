////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCSCALABLE_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCSCALABLE_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>
#include <string>
#include <ostream>

namespace dreamcloud { namespace base_types_clib {

////////////////////
//      USING     //
////////////////////
using std::string;
using std::ostream;
using std::istream;

enum dcScalingEnum
{
  femto = 1, pico, nano, micro, mili, none,
  kilo, mega, giga, tera
};

template<class T>
class dcScalable
  : public dcBaseType
{
public:
  dcScalable(const T &val, const string &scale) : value_(val), scale_(str_to_scaling_enum(scale)) { }
  dcScalable(const T &val = 0, dcScalingEnum scale = none) : value_(val), scale_(scale) { }

  ~dcScalable() { }

  friend ostream& operator<<(ostream& os, const dcScalable<T> &s) { return os << s.value_ << scaling_enum_to_str(s.scale_); }
  dcScalable<T> operator()() { return *this; }

  bool operator==(const dcScalable<T> &s) const { return value_ == s.convert_scale(scale_); }
  bool operator!=(const dcScalable<T> &s) const { return value_ != s.convert_scale(scale_); }
  bool operator>(const dcScalable<T> &s) const { return value_ > s.convert_scale(scale_); }
  bool operator<(const dcScalable<T> &s) const { return value_ < s.convert_scale(scale_); }
  bool operator>=(const dcScalable<T> &s) const { return value_ >= s.convert_scale(scale_); }
  bool operator<=(const dcScalable<T> &s) const { return value_ <= s.convert_scale(scale_); }

  dcScalable<T>& operator=(const dcScalable<T> &s) { value_ = s.value_; scale_ = s.scale_; return *this; }
  dcScalable<T>& operator=(const T &t) { value_ = t; scale_ = none; return *this; }

  inline dcBaseType* cpy() const { return new dcScalable( value_, scale_ ); }

  virtual inline const dcTypeEnum get_class_type() const { return dcScalable::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_scalable; }

protected:
  // empty

private:
  static dcScalingEnum str_to_scaling_enum(const string &scale)
  {
    if (scale.empty()) return none;

    switch (tolower(scale[0]))
    {
    case 'f' : return femto;
    case 'p' : return pico;
    case 'n' : return nano;
    case 'u' : return micro;
    case 'm' : return ((scale.find("meg") != string::npos) || (scale.find("MEG") != string::npos)) ? mega : mili;
    case 'k' : return kilo;
    case 'g' : return giga;
    case 't' : return tera;
    default : return none;
    }
  }

  static string scaling_enum_to_str(const dcScalingEnum &scale)
  {
    switch (scale)
    {
    case femto: return "f";
    case pico : return "p";
    case nano : return "n";
    case micro: return "u";
    case mili : return "m";
    case kilo : return "K";
    case mega : return "MEG";
    case giga : return "G";
    case tera : return "T";
    case none : return "";
    default: return "";
    }
  }

  inline static double get_factor(int exp)
  {
    static const double factor[] = {1e-30, 1e-27, 1e-24, 1e-21, 1e-18, 1e-15, 1e-12, 1e-9, 1e-6, 1e-3, 
                                    1, 1e3, 1e6, 1e9, 1e12, 1e15, 1e18, 1e21, 1e24, 1e27, 1e30};
    if ((exp > 10) || (exp < -10)) return 0.0;
    return factor[10 + exp];
  }

  inline T convert_scale(dcScalingEnum scale) const
  {
    return (scale_ == scale) ? value_ : T(value_ * get_factor(static_cast<int>(scale_) - static_cast<int>(scale)));
  }

  T value_;
  dcScalingEnum scale_;
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
