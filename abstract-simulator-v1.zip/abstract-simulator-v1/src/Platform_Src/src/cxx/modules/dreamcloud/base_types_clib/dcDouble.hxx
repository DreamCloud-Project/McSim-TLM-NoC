////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCDOUBLE_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCDOUBLE_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>

namespace dreamcloud { namespace base_types_clib {

class dcDouble
  : public dcBaseType
{
public:
  dcDouble(double val = 0) : val_(val) { }

  ~dcDouble() { }

  dcDouble operator+=(const double val) { val_ += val; return *this; }
  dcDouble operator*=(const double val) { val_ *= val; return *this; }

  dcDouble &operator()() { return *this; }
  operator double() const { return val_; }

  inline dcBaseType* cpy() const { return new dcDouble( val_ ); }

  virtual inline const dcTypeEnum get_class_type() const { return dcDouble::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_double; }

protected:
  // empty

private:
  double val_;
};

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
