////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef DREAMCLOUD__BASE_TYPES_CLIB__DCCONTAINER_HXX
#define DREAMCLOUD__BASE_TYPES_CLIB__DCCONTAINER_HXX

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/base_types_clib/dcBaseType.hxx>
#include <dreamcloud/base_types_clib/dcMap.hxx>
#include <dreamcloud/utilities_clib/Messenger.hxx>
#include <stdio.h>

namespace dreamcloud { namespace base_types_clib {

////////////////////
//      USING     //
////////////////////
using dreamcloud::utilities_clib::Messenger::error;

class Entry
{
public:
  inline Entry() : obj_(0), must_delete_(false) { }
  inline Entry(dcBaseType *obj, bool must_del = false) : obj_(obj), must_delete_(must_del) { }

  inline ~Entry() { if (must_delete_) delete obj_; }

  inline bool get_must_delete() const { return must_delete_; }
  inline void set_must_delete(bool must_delete) { must_delete_ = must_delete; }
  inline dcBaseType *get_obj() const { return obj_; }

  dcBaseType* operator()() { return obj_; }

  template<class T>
  operator T() const { return static_cast<T>(obj_); }

protected:
  //empty

private:
  dcBaseType *obj_;
  bool must_delete_;
};

template<class Key, class KeyCompare = std::less<Key> >
class dcContainer
  : public dcMap<Key,Entry,KeyCompare>
{
public:
  ////////////////////
  //    TYPEDEFS    //
  ////////////////////
  typedef dcMap<Key,Entry,KeyCompare> container;

  dcContainer() { }
  dcContainer(const dcContainer<Key,KeyCompare> &container);

  ~dcContainer() { }

  template<class T>
  void insert(const Key &key, T *val);

  template<class T>
  void insert(const Key &key, const T &val);

  template<class T>
  bool find(const Key &key, T *&val, bool quiet = false) const;

  virtual inline const dcTypeEnum get_class_type() const { return dcContainer::class_type(); }
  static inline const dcTypeEnum class_type() { return dc_container; }

protected:
  //empty

private:
  //empty
};

template<class Key, class KeyCompare>
dcContainer<Key,KeyCompare>::dcContainer(const dcContainer<Key,KeyCompare> &container)
{
  for (typename dcContainer<Key,KeyCompare>::const_iterator it(container.begin());
       it != container.end(); ++it)
  {
    if (it->second.get_must_delete())
    {
      dcBaseType *cpy(it->second.get_obj()->cpy());
      container::insert(make_pair(it->first, Entry(cpy)));
      (*this)[it->first].set_must_delete(true);
    }
    else
      insert(it->first, it->second.get_obj());
  }
}

template<class Key, class KeyCompare>
template<class T>
void dcContainer<Key,KeyCompare>::insert(const Key &key, T *val)
{
  typename container::iterator it(container::find(key));
  if (it != container::end()) // i.e. if an element with the same key already exists in the map
    container::erase(key);

  container::insert(std::make_pair(key, Entry(val)));
}

template<class Key, class KeyCompare>
template<class T>
void dcContainer<Key,KeyCompare>::insert(const Key &key, const T &val)
{
  typename container::iterator it(container::find(key));
  if (it != container::end()) // i.e. if an element with the same key already exists in the map
    container::erase(key);



  // Make a copy of the object, which must be deleted afterwards in the destructor of Entry
  container::insert(std::make_pair(key, Entry(new T(val), true)));
}

template<class Key, class KeyCompare>
template<class T>
bool dcContainer<Key,KeyCompare>::find(const Key &key, T *&val, bool quiet) const
{
  bool found(false);
  typename container::const_iterator it(container::find(key));

  if (it != container::end())
  {
    T *found_val = dcBaseType::dc_obj_cast<T>(it->second.get_obj());
    if (!found_val && !quiet) 
      error("Cannot get element [%s] because the specified type is not correct", key);
    else 
    { 
      found = true; 
      val = found_val; 
    }
  }

  return found;
}

}}

#endif

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
