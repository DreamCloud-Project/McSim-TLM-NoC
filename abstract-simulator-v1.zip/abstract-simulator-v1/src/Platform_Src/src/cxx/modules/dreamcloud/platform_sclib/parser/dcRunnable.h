#ifndef RUNNABLE_H_
#define RUNNABLE_H_

#include <iostream>
#include <string>
#include <vector>
#include "dcInstruction.h"
#include "dcRemoteAccessInstruction.h"
#include "dcTag.h"
#include "dcRunnableExecutionTime.h"
#include "dcActEvent.h"
#include "dcRunnableEdge.h"
#include "dcPeriodicEvent.h"
#include "dcSporadicEvent.h"

namespace DCApplication{
	using namespace std;

	class dcRunnableEdge;

	class dcRunnable
	{

		public:
			vector<dcRunnable*> GetListOfEnables();
			vector<dcRunnable*> GetListOfEnablers();
		
			dcActEvent* GetActEvent();
			void SetActEvent(dcActEvent* dcActEventIn);


			dcRunnable(string NameIn);
			string GetName();
			void SetName(string NameIn);
			void SetID(string IDIn);
			string GetID();
			void SetEdges(dcRunnableEdge* RunEdgeIn);
			dcRunnableEdge* GetEdges();
			void SetNext(dcRunnable *NextIn);
			dcRunnable* GetNext();
			string GetRunSource();
			void SetRunSource(string RunSourceIn);
			vector<string> GetRunnableDestination();
			void SetRunnableDestination(vector<string> RunDestinationIn);

			void SetTags(dcTag* TagsIn);
			dcTag* GetTags();
			int GetSize();
			void SetSize(int SizeIn);
			void SetInstructions(vector<dcInstruction*> InstructionIn);
			int GetPriority();
			void SetPriority(int PriorityIn);
			string GetPreemption();
			void SetPreemption(string PreemptionIn);
			vector<dcInstruction*> GetAllInstructions();
			vector<string> GetReleasedTasks();
			void SetReleasedTasks(vector<string> releasedTaskIn);

			void SetOrderedTaskReleased(bool OrderedTaskReleasedIn);
			bool GetOrderedTaskReleased();
			void SetRunnableExecutionTime(dcRunnableExecutionTime* MyExecutionTimeIn);
			dcRunnableExecutionTime* GetRunnableExecutionTime();

			void SetDeadline(pair<int,string> DeadlineIn);
			int GetDeadlineValue();
			unsigned long int GetDeadlineValueInNano();
			string GetDeadlineUnit();

			dcRunnable* GetTail();
			void SetTail(dcRunnable* TailIn);
			
			void SetStartTime(unsigned  long int x);
			unsigned long int GetStartTime();
			void SetCompletionTime(unsigned  long int x);
			unsigned long int GetCompletionTime();

			void SetMappingTime(unsigned  long int x);
			unsigned long int GetMappingTime();

			void SetCoreReceiveTime(unsigned  long int x);
			unsigned long int GetCoreReceiveTime();
		

			void SetWaveID(int x);
			int GetWaveID();
			
			int GetRunnableID();
			void SetRunnableID(int RunnableIDIn);

			int GetPeriodicallyExecuted();
			unsigned long GetPeriodInNano();
			unsigned long GetOffsetInNano();
			void SetPeriodicallyExecuted(int executed);

			void SetEnabledBy(int x);
			unsigned int GetEnabledBy();

			vector<string> getReadLabelsIdsBySize();

		private:
			dcActEvent *ActEvent_;
			
			string ID;
			string Name;
			dcRunnableEdge* RunEdge;
			dcRunnable *Next;
			dcRunnable *Tail;
			string RunSource;
			vector<string> RunDestination;

			dcTag* Tags;
			vector<dcInstruction*> Instructions;
			vector<dcInstruction*> readInstructions;
			int Size;
			vector<string> ReleasedTasks;
			bool OrderedTaskReleased;
			dcRunnableExecutionTime* ExecutionTime;
			int Priority;
			string Preemption;

			pair<int,string> Deadline;
			unsigned long int execution_time_start;
			unsigned long int execution_time_completition;
			unsigned long int allocation_time;
			unsigned long int core_receive_time;
			int waveID;
			
			int RunnableID;
			int enabledBy = 1;

	};

}
#endif /* RUNNABLE_H_ */
