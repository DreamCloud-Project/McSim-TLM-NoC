////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                           DREAMCLOUD PROJECT                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

////////////////////
//    INCLUDES    //
////////////////////
#include <dreamcloud/platform_sclib/NoC_PPA/nocInterconnect.hxx>
#include <dreamcloud/platform_sclib/NoC_PPA/packet.hxx>
#include <dreamcloud/base_types_clib/dcSharedPointer.hxx>
#include <dreamcloud/utilities_clib/Messenger.hxx>
#include <dreamcloud/platform_sclib/dcSystem.hxx>
#include <dreamcloud/platform_sclib/dcSimuParams.hxx>

////////////////////
//      USING     //
////////////////////
using namespace dreamcloud::platform_sclib;

using namespace dreamcloud::platform_sclib::noc_ppa;
using namespace dreamcloud::base_types_clib;
using namespace dreamcloud::utilities_clib::Messenger;
using namespace std;

int sc_main(int argc, char** argv) {

	// Parse arguments
	dcSimuParams params(argc, argv);
	if (params.getHelp()) {
		params.printHelp();
		exit(0);
	}

    // SystemC evaluation
	sc_core::sc_report_handler::set_actions("/IEEE_Std_1666/deprecated",
			sc_core::SC_DO_NOTHING);
	debug_level(5);
	sc_clock clock("my_clock", CLOCK_PERIOD, SC_NS, 0.5);
	dcSystem system("dcSsytem", params);
	system.clock(clock);
	//new dcSystem("dcSsytem", params);

	// SystemC simulation
	sc_start();
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  END OF FILE.                                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
